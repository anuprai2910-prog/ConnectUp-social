import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, ReactNode, useContext, useEffect, useMemo, useState } from 'react';

export type PostImage = 'city' | 'cafe' | 'none';
export type PostMedia = { uri: string; type: 'image' | 'video'; fileName?: string | null } | null;
export interface Comment { id: string; author: string; text: string; time: string; }
export interface Post { id: string; author: string; handle: string; initials: string; time: string; text: string; image: PostImage; media?: PostMedia; likes: number; liked: boolean; saved: boolean; comments: Comment[]; }
export interface NotificationItem { id: string; kind: 'like' | 'comment' | 'follow'; actor: string; initials: string; text: string; time: string; read: boolean; }
export interface UserProfile { name: string; handle: string; bio: string; initials: string; email?: string; avatarUri?: string; }
export interface PersonProfile { name: string; handle: string; bio: string; initials: string; followers: number; avatarImage?: PostImage; online?: boolean; }
export interface Message { id: string; from: string; to: string; text: string; time: string; read: boolean; }
export interface Story { id: string; username: string; text: string; mediaUrl?: string | null; mediaType?: string | null; createdAt: string; expiresAt: string; viewed: boolean; reaction?: string | null; }
export interface AppSettings { privateAccount: boolean; notifications: boolean; darkMode: boolean; }
interface LocalAccount { username: string; email: string; }
interface StoredState { stories?: Story[]; isAuthenticated: boolean; token?: string; user: UserProfile; account?: LocalAccount; posts: Post[]; notifications: NotificationItem[]; profiles: PersonProfile[]; following: string[]; messages: Message[]; settings: AppSettings; }
interface AppContextValue {
  isHydrated: boolean; isAuthenticated: boolean; user: UserProfile; stories: Story[]; posts: Post[]; notifications: NotificationItem[]; profiles: PersonProfile[]; following: string[]; messages: Message[]; settings: AppSettings;
  signIn: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  createAccount: (username: string, email: string) => void; signOut: () => void;
  addPost: (text: string, image: PostImage, media?: PostMedia) => void; toggleLike: (postId: string) => void; toggleSave: (postId: string) => void;
  addComment: (postId: string, text: string) => void; markNotificationsRead: () => void; updateProfile: (name: string, bio: string) => void;
  isFollowing: (handle: string) => boolean; toggleFollow: (handle: string) => void; sendMessage: (to: string, text: string) => void;
  loadStories: () => Promise<void>; createStory: (text: string, mediaUrl?: string | null, mediaType?: string | null) => Promise<{ok:boolean;error?:string}>; viewStory: (id:string) => Promise<void>; reactToStory: (id:string, reaction?:string) => Promise<void>; removeStoryReaction: (id:string) => Promise<void>; getStoryViewers: (id:string) => Promise<{username:string;viewedAt:string}[]>;
  markConversationRead: (handle: string) => void; deleteMessage: (messageId: string) => void; conversationWith: (handle: string) => Message[]; updateSettings: (patch: Partial<AppSettings>) => void; resetLocalData: () => Promise<void>;
}

const defaultUser: UserProfile = { name: 'Jordan Lee', handle: 'jordanlee', bio: 'Finding the good in ordinary days.', initials: 'JL' };
const defaultProfiles: PersonProfile[] = [
  { name: 'Maya Chen', handle: 'mayachen', bio: 'City walks and bright mornings.', initials: 'MC', followers: 1240, avatarImage: 'city', online: true },
  { name: 'Eli Walker', handle: 'eliwalks', bio: 'Slow mornings. Good coffee.', initials: 'EW', followers: 890, avatarImage: 'cafe', online: true },
  { name: 'Priya Shah', handle: 'priyashah', bio: 'One more coffee?', initials: 'PS', followers: 2100, avatarImage: 'none', online: false },
  { name: 'Noah Williams', handle: 'noahw', bio: 'Stories, music and everyday life.', initials: 'NW', followers: 740, avatarImage: 'none', online: true },
  { name: 'Ava Park', handle: 'avapark', bio: 'Making space for good things.', initials: 'AP', followers: 1560, avatarImage: 'none', online: false },
];
const defaultPosts: Post[] = [
  { id:'post-1', author:'Maya Chen', handle:'mayachen', initials:'MC', time:'2h', text:'A little sunshine and a lot of catching up. The city feels brand new today.', image:'city', likes:246, liked:false, saved:false, comments:[{id:'comment-1',author:'Noah Williams',text:'This is such a good day.',time:'1h'},{id:'comment-2',author:'Jordan Lee',text:'The light is perfect.',time:'48m'}] },
  { id:'post-2', author:'Eli Walker', handle:'eliwalks', initials:'EW', time:'5h', text:'Slow mornings are underrated. What is one small ritual that makes your day better?', image:'cafe', likes:128, liked:true, saved:true, comments:[{id:'comment-3',author:'Priya Shah',text:'A walk before my first meeting.',time:'3h'}] },
  { id:'post-3', author:'Priya Shah', handle:'priyashah', initials:'PS', time:'1d', text:'The best conversations usually start with “one more coffee?”', image:'none', likes:89, liked:false, saved:false, comments:[] },
];
const defaultNotifications: NotificationItem[] = [
  {id:'notification-1',kind:'like',actor:'Lena Ortiz',initials:'LO',text:'liked your post',time:'14m',read:false},
  {id:'notification-2',kind:'comment',actor:'Noah Williams',initials:'NW',text:'commented on your post',time:'1h',read:false},
  {id:'notification-3',kind:'follow',actor:'Ava Park',initials:'AP',text:'started following you',time:'3h',read:true},
  {id:'notification-4',kind:'like',actor:'Maya Chen',initials:'MC',text:'liked your post',time:'Yesterday',read:true},
];
const defaultSettings: AppSettings = { privateAccount:false, notifications:true, darkMode:false };
const STORAGE_KEY='@hitsun/state';
const API_BASE = process.env.EXPO_PUBLIC_DOMAIN ? `https://${process.env.EXPO_PUBLIC_DOMAIN}` : '';
const api = (path: string) => `${API_BASE}/api${path}`;
const formatMessageTime = (iso: string) => { const d = new Date(iso); return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); };
const AppContext=createContext<AppContextValue|null>(null);

export function AppProvider({children}:{children:ReactNode}) {
  const [isHydrated,setIsHydrated]=useState(false); const [isAuthenticated,setIsAuthenticated]=useState(false); const [token,setToken]=useState('');
  const [user,setUser]=useState<UserProfile>(defaultUser); const [account,setAccount]=useState<LocalAccount|null>(null);
  const [posts,setPosts]=useState<Post[]>(defaultPosts); const [notifications,setNotifications]=useState<NotificationItem[]>(defaultNotifications);
  const [profiles,setProfiles]=useState<PersonProfile[]>(defaultProfiles); const [following,setFollowing]=useState<string[]>([]);
  const [messages,setMessages]=useState<Message[]>([]); const [stories,setStories]=useState<Story[]>([]); const [settings,setSettings]=useState<AppSettings>(defaultSettings);

  useEffect(()=>{ AsyncStorage.getItem(STORAGE_KEY).then(stored=>{ if(!stored)return; const p=JSON.parse(stored) as Partial<StoredState>;
    if(typeof p.isAuthenticated==='boolean')setIsAuthenticated(p.isAuthenticated); if(p.token)setToken(p.token); if(p.user)setUser(p.user); if(p.account)setAccount(p.account);
    if(p.posts)setPosts(p.posts); if(p.notifications)setNotifications(p.notifications); if(p.profiles)setProfiles(p.profiles); if(p.following)setFollowing(p.following); if(p.messages)setMessages(p.messages); if(p.stories)setStories(p.stories.filter(s=>new Date(s.expiresAt).getTime()>Date.now())); if(p.settings)setSettings({...defaultSettings,...p.settings});
  }).catch(()=>undefined).finally(()=>setIsHydrated(true)); },[]);
  useEffect(()=>{if(!isHydrated)return; const state:StoredState={isAuthenticated,token:token||undefined,user,account:account??undefined,posts,notifications,profiles,following,messages,stories,settings}; AsyncStorage.setItem(STORAGE_KEY,JSON.stringify(state)).catch(()=>undefined)},[isHydrated,isAuthenticated,token,user,account,posts,notifications,profiles,following,messages,settings]);

  const syncMessages = async (authToken = token) => {
    if (!authToken) return;
    try {
      const res = await fetch(api('/messages'), { headers: { Authorization: `Bearer ${authToken}` } });
      if (res.status === 401) { setIsAuthenticated(false); setToken(''); return; }
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data.messages)) setMessages(data.messages.map((m: any) => ({ id:String(m.id), from:String(m.from), to:String(m.to), text:String(m.text), time:formatMessageTime(String(m.createdAt)), read:Boolean(m.read) })));
    } catch { /* keep cached messages while offline */ }
  };

  useEffect(()=>{
    if (!isHydrated || !isAuthenticated || !token) return;
    syncMessages();
    const timer = setInterval(() => syncMessages(), 2500);
    return () => clearInterval(timer);
  },[isHydrated,isAuthenticated,token]);

  const loadStories = async () => {
    if (!token) return;
    try { const res=await fetch(api('/stories'),{headers:{Authorization:`Bearer ${token}`}}); if(!res.ok)return; const data=await res.json(); if(Array.isArray(data.stories)) setStories(data.stories); } catch {}
  };
  const createStory = async (text:string, mediaUrl:string|null=null, mediaType:string|null=null) => {
    if(!token) return {ok:false,error:'Please log in first.'};
    try { const res=await fetch(api('/stories'),{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({text,mediaUrl,mediaType})}); const data=await res.json().catch(()=>({})); if(!res.ok)return {ok:false,error:data.error||'Could not publish story.'}; setStories(c=>[...c,data]); return {ok:true}; } catch { return {ok:false,error:'Unable to connect to the server.'}; }
  };
  const viewStory = async (id:string) => { setStories(c=>c.map(x=>x.id===id?{...x,viewed:true}:x)); if(token) fetch(api(`/stories/${id}/view`),{method:'POST',headers:{Authorization:`Bearer ${token}`}}).catch(()=>undefined); };
  const reactToStory = async (id:string,reaction='❤️') => { setStories(c=>c.map(x=>x.id===id?{...x,reaction}:x)); if(token) fetch(api(`/stories/${id}/react`),{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({reaction})}).catch(()=>undefined); };
  const removeStoryReaction = async (id:string) => { setStories(c=>c.map(x=>x.id===id?{...x,reaction:null}:x)); if(token) fetch(api(`/stories/${id}/react`),{method:'DELETE',headers:{Authorization:`Bearer ${token}`}}).catch(()=>undefined); };
  const getStoryViewers = async (id:string) => { if(!token)return []; try{const r=await fetch(api(`/stories/${id}/viewers`),{headers:{Authorization:`Bearer ${token}`}}); if(!r.ok)return []; const d=await r.json(); return Array.isArray(d.viewers)?d.viewers:[];}catch{return [];} };

  const signIn=async(email:string,password:string)=>{
    try { const res=await fetch(api('/auth/login'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:email.trim().toLowerCase(),password})});
      const data=await res.json().catch(()=>({})); if(!res.ok) return {ok:false,error:data.error||'Invalid email or password.'};
      const username=String(data.username||email.split('@')[0]); const name=username.replace(/[_-]+/g,' '); const initials=name.split(/\s+/).map(x=>x[0]||'').join('').slice(0,2).toUpperCase()||'HU';
      const nextToken=String(data.token||''); if(!nextToken) return {ok:false,error:'The server did not return a login session.'};
      setToken(nextToken); setAccount({username,email:email.trim().toLowerCase()}); setUser({name,handle:username.toLowerCase(),bio:'Making room for more.',initials,email:email.trim().toLowerCase()}); setIsAuthenticated(true); await syncMessages(nextToken); return {ok:true};
    } catch { return {ok:false,error:'Unable to connect to the server. Please try again.'}; }
  };
  const createAccount=(username:string,email:string)=>{const clean=username.trim(); const handle=clean.toLowerCase().replace(/[^a-z0-9_]/g,'').slice(0,20)||'hitsunuser'; const name=clean; const initials=name.split(/\s+/).map(p=>p[0]||'').join('').slice(0,2).toUpperCase()||'HU'; setAccount({username:clean,email:email.trim().toLowerCase()}); setUser({name,handle,bio:'New to HITSUN. Making room for more.',initials,email:email.trim().toLowerCase()}); setIsAuthenticated(true); };
  const signOut=()=>{const oldToken=token; setIsAuthenticated(false);setToken('');setAccount(null);setUser(defaultUser);setMessages([]); setStories([]); if(oldToken) fetch(api('/auth/logout'),{method:'POST',headers:{Authorization:`Bearer ${oldToken}`}}).catch(()=>undefined);};
  const addPost=(text:string,image:PostImage,media:PostMedia=null)=>setPosts(c=>[{id:`post-${Date.now()}`,author:user.name,handle:user.handle,initials:user.initials,time:'now',text,image,media,likes:0,liked:false,saved:false,comments:[]},...c]);
  const toggleLike=(id:string)=>setPosts(c=>c.map(p=>p.id===id?{...p,liked:!p.liked,likes:p.likes+(p.liked?-1:1)}:p));
  const toggleSave=(id:string)=>setPosts(c=>c.map(p=>p.id===id?{...p,saved:!p.saved}:p));
  const addComment=(id:string,text:string)=>{const comment={id:`comment-${Date.now()}`,author:user.name,text,time:'now'};setPosts(c=>c.map(p=>p.id===id?{...p,comments:[...p.comments,comment]}:p));setNotifications(c=>[{id:`notification-${Date.now()}`,kind:'comment',actor:user.name,initials:user.initials,text:'commented on a post',time:'now',read:false},...c]);};
  const markNotificationsRead=()=>setNotifications(c=>c.map(n=>({...n,read:true})));
  const updateProfile=(name:string,bio:string)=>setUser(c=>({...c,name:name.trim()||c.name,bio:bio.trim(),initials:(name.trim()||c.name).split(/\s+/).map(p=>p[0]||'').join('').slice(0,2).toUpperCase()}));
  const isFollowing=(handle:string)=>following.includes(handle);
  const toggleFollow=(handle:string)=>{const person=profiles.find(p=>p.handle===handle); const already=following.includes(handle); setFollowing(c=>already?c.filter(x=>x!==handle):[...c,handle]); if(person&&!already)setNotifications(c=>[{id:`notification-${Date.now()}`,kind:'follow',actor:person.name,initials:person.initials,text:'started following you',time:'now',read:false},...c]);};
  const sendMessage=(to:string,text:string)=>{const value=text.trim();if(!value||!token)return; const optimistic={id:`pending-${Date.now()}`,from:user.handle,to:to.toLowerCase(),text:value,time:'now',read:true}; setMessages(c=>[...c,optimistic]); fetch(api('/messages'),{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({to:to.toLowerCase(),text:value})}).then(async res=>{if(!res.ok){setMessages(c=>c.filter(m=>m.id!==optimistic.id));return;} await syncMessages();}).catch(()=>setMessages(c=>c.filter(m=>m.id!==optimistic.id))); };
  const markConversationRead=(handle:string)=>{setMessages(c=>c.map(m=>m.from===handle&&m.to===user.handle?{...m,read:true}:m)); if(token) fetch(api('/messages/read'),{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({from:handle})}).catch(()=>undefined);};
  const deleteMessage=(messageId:string)=>{setMessages(c=>c.filter(m=>m.id!==messageId)); if(token&&!messageId.startsWith('pending-')) fetch(api(`/messages/${encodeURIComponent(messageId)}`),{method:'DELETE',headers:{Authorization:`Bearer ${token}`}}).catch(()=>undefined);};
  const conversationWith=(handle:string)=>messages.filter(m=>(m.from===user.handle&&m.to===handle)||(m.from===handle&&m.to===user.handle));
  const updateSettings=(patch:Partial<AppSettings>)=>setSettings(c=>({...c,...patch}));
  const resetLocalData=async()=>{await AsyncStorage.removeItem(STORAGE_KEY);setIsAuthenticated(false);setToken('');setAccount(null);setUser(defaultUser);setPosts(defaultPosts);setNotifications(defaultNotifications);setProfiles(defaultProfiles);setFollowing([]);setMessages([]);setStories([]);setSettings(defaultSettings);};
  const value=useMemo<AppContextValue>(()=>({isHydrated,isAuthenticated,user,stories,posts,notifications,profiles,following,messages,settings,signIn,createAccount,signOut,addPost,toggleLike,toggleSave,addComment,markNotificationsRead,updateProfile,isFollowing,toggleFollow,sendMessage,markConversationRead,deleteMessage,conversationWith,updateSettings,resetLocalData,loadStories,createStory,viewStory,reactToStory,removeStoryReaction,getStoryViewers}),[isHydrated,isAuthenticated,user,posts,notifications,profiles,following,messages,stories,settings,token]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
export function useApp(){const context=useContext(AppContext);if(!context)throw new Error('useApp must be used within AppProvider');return context;}
