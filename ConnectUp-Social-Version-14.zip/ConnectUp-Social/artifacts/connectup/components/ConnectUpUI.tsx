import { Feather, Ionicons } from '@expo/vector-icons';
import React from 'react';
import {
  Image,
  ImageSourcePropType,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import type { Post } from '@/context/AppContext';
import type { PostMedia } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

const cityImage = require('@/assets/images/feed-city.jpg') as ImageSourcePropType;
const cafeImage = require('@/assets/images/feed-cafe.jpg') as ImageSourcePropType;

export const feedImages: Record<'city' | 'cafe', ImageSourcePropType> = {
  city: cityImage,
  cafe: cafeImage,
};

export function PostMediaPreview({
  media,
  height = 228,
}: {
  media: PostMedia;
  height?: number;
}) {
  const colors = useColors();
  if (!media) return null;

  if (media.type === 'image') {
    return <Image source={{ uri: media.uri }} style={[styles.postImage, { height }]} resizeMode="cover" />;
  }

  return (
    <View style={[styles.videoPreview, { backgroundColor: colors.ink, height }]}>
      <View style={[styles.videoPlay, { backgroundColor: colors.sun }]}>
        <Feather name="play" size={20} color={colors.ink} />
      </View>
      <Text style={[styles.videoLabel, { color: colors.background }]}>Video selected</Text>
      {media.fileName ? <Text style={[styles.videoFileName, { color: colors.muted }]} numberOfLines={1}>{media.fileName}</Text> : null}
    </View>
  );
}

export function Avatar({
  initials,
  size = 44,
  index = 0,
  image,
}: {
  initials: string;
  size?: number;
  index?: number;
  image?: ImageSourcePropType;
}) {
  const colors = useColors();
  return image ? (
    <Image source={image} style={[styles.avatar, { width: size, height: size, borderRadius: size / 2 }]} />
  ) : (
    <View
      style={[
        styles.avatar,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: colors.avatarPalette[index % colors.avatarPalette.length],
        },
      ]}
    >
      <Text style={[styles.avatarText, { color: colors.ink }]}>{initials}</Text>
    </View>
  );
}

export function IconButton({
  name,
  onPress,
  color,
  size = 21,
  testID,
}: {
  name: keyof typeof Feather.glyphMap;
  onPress?: () => void;
  color?: string;
  size?: number;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      hitSlop={10}
      onPress={onPress}
      style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
      testID={testID}
    >
      <Feather name={name} size={size} color={color ?? colors.ink} />
    </Pressable>
  );
}

export function Wordmark({ compact = false }: { compact?: boolean }) {
  const colors = useColors();
  return (
    <View style={styles.wordmark}>
      <View style={[styles.wordmarkMark, { backgroundColor: colors.sun }]}>
          <Ionicons name="sunny" size={18} color={colors.ink} />
      </View>
      {!compact && <Text style={[styles.wordmarkText, { color: colors.ink }]}>HITSUN</Text>}
    </View>
  );
}

export function PostCard({
  post,
  onLike,
  onComment,
  onShare,
  onSave,
}: {
  post: Post;
  onLike: () => void;
  onComment: () => void;
  onShare: () => void;
  onSave: () => void;
}) {
  const colors = useColors();
  const image = post.image === 'none' ? null : feedImages[post.image];
  return (
    <View style={[styles.postCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.postHeader}>
        <Avatar initials={post.initials} index={post.id.length} />
        <View style={styles.postAuthor}>
          <Text style={[styles.authorName, { color: colors.ink }]}>{post.author}</Text>
          <Text style={[styles.authorMeta, { color: colors.mutedForeground }]}>
            @{post.handle} <Text style={{ color: colors.borderStrong }}>·</Text> {post.time}
          </Text>
        </View>
        <IconButton name="more-horizontal" color={colors.mutedForeground} size={20} />
      </View>
      <Text style={[styles.postText, { color: colors.ink }]}>{post.text}</Text>
      {post.media ? <PostMediaPreview media={post.media} /> : image && <Image source={image} style={styles.postImage} resizeMode="cover" />}
      <View style={styles.postActions}>
        <View style={styles.actionCluster}>
          <Pressable onPress={onLike} style={({ pressed }) => [styles.actionButton, pressed && styles.pressed]} testID={`like-${post.id}`}>
            <Ionicons name={post.liked ? 'heart' : 'heart-outline'} size={21} color={post.liked ? colors.coral : colors.ink} />
            <Text style={[styles.actionCount, { color: post.liked ? colors.coral : colors.ink }]}>{post.likes}</Text>
          </Pressable>
          <Pressable onPress={onComment} style={({ pressed }) => [styles.actionButton, pressed && styles.pressed]} testID={`comment-${post.id}`}>
            <Feather name="message-circle" size={19} color={colors.ink} />
            <Text style={[styles.actionCount, { color: colors.ink }]}>{post.comments.length}</Text>
          </Pressable>
          <Pressable onPress={onShare} style={({ pressed }) => [styles.actionButton, pressed && styles.pressed]} testID={`share-${post.id}`}>
            <Feather name="send" size={18} color={colors.ink} />
          </Pressable>
        </View>
        <Pressable onPress={onSave} style={({ pressed }) => [styles.actionButton, pressed && styles.pressed]} testID={`save-${post.id}`}>
          <Ionicons name={post.saved ? 'bookmark' : 'bookmark-outline'} size={20} color={post.saved ? colors.coral : colors.ink} />
        </Pressable>
      </View>
    </View>
  );
}

export function EmptyState({ title, message, icon = 'search' }: { title: string; message: string; icon?: keyof typeof Feather.glyphMap }) {
  const colors = useColors();
  return (
    <View style={[styles.emptyState, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.sand }]}>
        <Feather name={icon} size={24} color={colors.coral} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.ink }]}>{title}</Text>
      <Text style={[styles.emptyMessage, { color: colors.mutedForeground }]}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  pressed: { opacity: 0.65, transform: [{ scale: 0.98 }] },
  iconButton: { alignItems: 'center', justifyContent: 'center', width: 32, height: 32 },
  avatar: { alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: -0.3 },
  wordmark: { alignItems: 'center', flexDirection: 'row', gap: 8 },
  wordmarkMark: { alignItems: 'center', borderRadius: 9, height: 28, justifyContent: 'center', transform: [{ rotate: '-10deg' }], width: 28 },
  wordmarkLoop: { borderRadius: 8, height: 13, transform: [{ rotate: '24deg' }], width: 7 },
  wordmarkText: { fontFamily: 'Inter_700Bold', fontSize: 18, letterSpacing: 1.8 },
  postCard: { borderRadius: 22, borderWidth: 1, marginBottom: 14, overflow: 'hidden', paddingTop: 16 },
  postHeader: { alignItems: 'center', flexDirection: 'row', paddingHorizontal: 16 },
  postAuthor: { flex: 1, marginLeft: 11 },
  authorName: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  authorMeta: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 3 },
  postText: { fontFamily: 'Inter_400Regular', fontSize: 15, lineHeight: 22, paddingHorizontal: 16, paddingVertical: 14 },
  postImage: { height: 228, width: '100%' },
  videoPreview: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24, width: '100%' },
  videoPlay: { alignItems: 'center', borderRadius: 28, height: 56, justifyContent: 'center', width: 56 },
  videoLabel: { fontFamily: 'Inter_700Bold', fontSize: 14, marginTop: 13 },
  videoFileName: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 5, maxWidth: 220 },
  postActions: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', padding: 11 },
  actionCluster: { alignItems: 'center', flexDirection: 'row', gap: 17 },
  actionButton: { alignItems: 'center', flexDirection: 'row', gap: 6, minHeight: 32 },
  actionCount: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  emptyState: { alignItems: 'center', borderRadius: 22, borderWidth: 1, marginTop: 12, padding: 28 },
  emptyIcon: { alignItems: 'center', borderRadius: 18, height: 52, justifyContent: 'center', marginBottom: 14, width: 52 },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  emptyMessage: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, marginTop: 8, maxWidth: 260, textAlign: 'center' },
});

export const uiStyles = styles;