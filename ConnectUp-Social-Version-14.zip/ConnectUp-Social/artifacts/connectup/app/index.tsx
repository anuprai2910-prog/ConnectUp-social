import { Feather, Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';
import { Wordmark } from '@/components/ConnectUpUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';

export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isAuthenticated, isHydrated, signIn } = useApp();
  const [busy, setBusy] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (isHydrated && isAuthenticated) router.replace('/(tabs)');
  }, [isAuthenticated, isHydrated]);

  const handleLogin = async () => {
    const normalizedEmail = email.trim().toLowerCase();
    const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail);
    if (!isEmailValid) {
      setError('Enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setError('Your password must be at least 6 characters.');
      return;
    }
    setError('');
    setBusy(true);
    const result = await signIn(normalizedEmail, password);
    setBusy(false);
    if (!result.ok) { setError(result.error ?? 'Invalid email or password.'); return; }
    router.replace('/(tabs)');
  };

  if (!isHydrated) {
    return <View style={[styles.loading, { backgroundColor: colors.background }]}><Wordmark /></View>;
  }

  return (
    <KeyboardAwareScrollViewCompat
      bottomOffset={72}
      contentContainerStyle={[styles.scroll, { paddingTop: insets.top + 26, paddingBottom: insets.bottom + 24 }]}
      style={[styles.screen, { backgroundColor: colors.background }]}
    >
        <View style={styles.loginTop}>
          <Wordmark />
          <View style={[styles.eyebrow, { backgroundColor: colors.sand }]}>
            <Ionicons name="sparkles-outline" size={13} color={colors.coral} />
            <Text style={[styles.eyebrowText, { color: colors.coral }]}>Make room for more</Text>
          </View>
        </View>
        <View style={styles.heroCopy}>
          <Text style={[styles.title, { color: colors.ink }]}>Your people,{"\n"}in one place.</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>A thoughtful space to share the everyday moments that make life feel connected.</Text>
        </View>
        <View style={styles.form}>
        <View>
            <Text style={[styles.label, { color: colors.ink }]}>Email address</Text>
            <TextInput
              autoCapitalize="none"
              keyboardType="email-address"
              onChangeText={setEmail}
              placeholder="you@example.com"
              placeholderTextColor={colors.placeholder}
              style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.ink }]}
              testID="login-email"
            />
          </View>
        <View>
            <Text style={[styles.label, { color: colors.ink }]}>Password</Text>
            <View style={styles.passwordWrap}>
              <TextInput
                autoCapitalize="none"
                onChangeText={setPassword}
                placeholder="Enter your password"
                placeholderTextColor={colors.placeholder}
                secureTextEntry
                style={[styles.input, styles.passwordInput, { backgroundColor: colors.card, borderColor: colors.border, color: colors.ink }]}
                testID="login-password"
              />
            </View>
          </View>
          {error ? <Text style={[styles.error, { color: colors.coral }]}>{error}</Text> : null}
          <Pressable onPress={handleLogin} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.ink }, pressed && styles.pressed]} testID="login-submit">
            <Text style={[styles.primaryButtonText, { color: colors.background }]}>{busy ? 'Signing in…' : 'Sign in'}</Text>
            <Feather name="arrow-up-right" size={18} color={colors.background} />
          </Pressable>
          <Pressable onPress={() => setError('Password reset is not connected yet. Create a new account or contact the app administrator.')} style={styles.forgotButton}>
            <Text style={[styles.forgotText, { color: colors.mutedForeground }]}>Forgot password?</Text>
          </Pressable>
        </View>
        <View style={styles.signupRow}>
          <Text style={[styles.signupPrompt, { color: colors.mutedForeground }]}>New to HITSUN?</Text>
          <Pressable onPress={() => router.push('/signup')} testID="go-to-signup">
            <Text style={[styles.signupLink, { color: colors.coral }]}>Create an account</Text>
          </Pressable>
        </View>
        <Text style={[styles.legal, { color: colors.placeholder }]}>By continuing, you agree to our Terms and Privacy Policy.</Text>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  loading: { alignItems: 'center', flex: 1, justifyContent: 'center' },
  scroll: { flexGrow: 1, paddingHorizontal: 24 },
  loginTop: { alignItems: 'flex-start', flexDirection: 'row', justifyContent: 'space-between' },
  eyebrow: { alignItems: 'center', borderRadius: 20, flexDirection: 'row', gap: 5, paddingHorizontal: 10, paddingVertical: 7 },
  eyebrowText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  heroCopy: { marginTop: 62 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 40, letterSpacing: -1.8, lineHeight: 43 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 15, lineHeight: 23, marginTop: 18, maxWidth: 320 },
  form: { gap: 17, marginTop: 42 },
  label: { fontFamily: 'Inter_600SemiBold', fontSize: 12, marginBottom: 8 },
  input: { borderRadius: 14, borderWidth: 1, fontFamily: 'Inter_400Regular', fontSize: 15, height: 54, paddingHorizontal: 16 },
  passwordWrap: { position: 'relative' },
  passwordInput: { paddingRight: 48 },
  error: { fontFamily: 'Inter_500Medium', fontSize: 12, marginTop: -4 },
  primaryButton: { alignItems: 'center', borderRadius: 15, flexDirection: 'row', height: 56, justifyContent: 'center', marginTop: 2, gap: 9 },
  primaryButtonText: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  forgotButton: { alignItems: 'center', paddingVertical: 2 },
  forgotText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  signupRow: { alignItems: 'center', flexDirection: 'row', gap: 5, justifyContent: 'center', marginTop: 'auto', paddingTop: 42 },
  signupPrompt: { fontFamily: 'Inter_400Regular', fontSize: 13 },
  signupLink: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  legal: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 16, marginTop: 18, textAlign: 'center' },
  pressed: { opacity: 0.82, transform: [{ scale: 0.985 }] },
});