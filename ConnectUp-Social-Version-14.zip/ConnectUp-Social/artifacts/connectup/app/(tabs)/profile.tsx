import { Feather, Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useMemo, useState } from 'react';
import {
  FlatList,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  Avatar,
  feedImages,
  IconButton,
  PostCard,
  uiStyles,
  Wordmark,
} from '@/components/ConnectUpUI';
import type { Post } from '@/context/AppContext';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

function ProfileGridItem({
  post,
  index,
  onPress,
}: {
  post: Post;
  index: number;
  onPress: () => void;
}) {
  const colors = useColors();

  const imageSource =
    post.media?.type === 'image'
      ? { uri: post.media.uri }
      : post.image !== 'none'
        ? feedImages[post.image]
        : null;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.gridItem,
        { backgroundColor: colors.softCard },
        pressed && uiStyles.pressed,
      ]}
      testID={`profile-post-${post.id}`}
    >
      {imageSource ? (
        <Image
          source={imageSource}
          style={styles.gridImage}
          resizeMode="cover"
        />
      ) : post.media?.type === 'video' ? (
        <View
          style={[
            styles.videoGrid,
            { backgroundColor: colors.ink },
          ]}
        >
          <Ionicons name="play" size={20} color={colors.sun} />
        </View>
      ) : (
        <View
          style={[
            styles.textGrid,
            {
              backgroundColor:
                colors.avatarPalette[
                  index % colors.avatarPalette.length
                ],
            },
          ]}
        >
          <Text
            style={[styles.textGridCopy, { color: colors.ink }]}
            numberOfLines={4}
          >
            {post.text}
          </Text>
        </View>
      )}

      {post.media?.type === 'video' && (
        <View
          style={[
            styles.videoBadge,
            { backgroundColor: colors.background },
          ]}
        >
          <Ionicons
            name="videocam"
            size={11}
            color={colors.ink}
          />
        </View>
      )}
    </Pressable>
  );
}

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const {
    posts,
    user,
    toggleLike,
    toggleSave,
    updateProfile,
    signOut,
  } = useApp();

  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [bio, setBio] = useState(user.bio);
  const [activeTab, setActiveTab] =
    useState<'posts' | 'saved'>('posts');
  const [selectedPostId, setSelectedPostId] =
    useState<string | null>(null);

  const profilePosts = useMemo(
    () =>
      activeTab === 'posts'
        ? posts.filter((post) => post.handle === user.handle)
        : posts.filter((post) => post.saved),
    [activeTab, posts, user.handle],
  );

  const selectedPost = profilePosts.find(
    (post) => post.id === selectedPostId,
  );

  const saveProfile = () => {
    if (name.trim()) {
      updateProfile(name.trim(), bio.trim());
    }

    setEditing(false);
  };

  const handleLogout = async () => {
  signOut();
  await new Promise(resolve => setTimeout(resolve, 300));
  router.replace('/');
};

  return (
    <View
      style={[
        styles.screen,
        { backgroundColor: colors.background },
      ]}
    >
      <FlatList
        data={profilePosts}
        keyExtractor={(item) => item.id}
        numColumns={3}
        columnWrapperStyle={styles.gridRow}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingBottom:
            insets.bottom +
            (Platform.OS === 'web' ? 94 : 88),
        }}
        ListHeaderComponent={
          <View
            style={{
              paddingTop: insets.top + 10,
            }}
          >
            {/* TOP BAR */}
            <View style={styles.topBar}>
              <Wordmark />

              <View style={styles.topActions}>
                <IconButton
                  name="message-circle"
                  onPress={() => router.push('/messages')}
                  testID="profile-messages"
                />

                <IconButton
                  name="settings"
                  onPress={() => router.push('/settings')}
                  testID="profile-settings"
                />

                <IconButton
                  name="log-out"
                  onPress={handleLogout}
                  color={colors.coral}
                  testID="profile-logout"
                />
              </View>
            </View>

            {/* PROFILE HEADER */}
            <View style={styles.profileHead}>
              <View
                style={[
                  styles.profileAvatarRing,
                  { borderColor: colors.coral },
                ]}
              >
                <Avatar
                  initials={user.initials}
                  size={84}
                  index={0}
                />
              </View>

              <Text
                style={[
                  styles.profileName,
                  { color: colors.ink },
                ]}
              >
                {user.name}
              </Text>

              <Text
                style={[
                  styles.profileHandle,
                  { color: colors.mutedForeground },
                ]}
              >
                @{user.handle}
              </Text>

              <Text
                style={[
                  styles.profileBio,
                  { color: colors.ink },
                ]}
              >
                {user.bio}
              </Text>

              <Pressable
                onPress={() =>
                  setEditing((current) => !current)
                }
                style={({ pressed }) => [
                  styles.editButton,
                  { borderColor: colors.borderStrong },
                  pressed && uiStyles.pressed,
                ]}
                testID="edit-profile"
              >
                <Feather
                  name="edit-2"
                  size={14}
                  color={colors.ink}
                />

                <Text
                  style={[
                    styles.editText,
                    { color: colors.ink },
                  ]}
                >
                  {editing ? 'Close editor' : 'Edit profile'}
                </Text>
              </Pressable>
            </View>

            {/* EDIT PROFILE */}
            {editing && (
              <View
                style={[
                  styles.editCard,
                  {
                    backgroundColor: colors.card,
                    borderColor: colors.border,
                  },
                ]}
              >
                <TextInput
                  value={name}
                  onChangeText={setName}
                  placeholder="Name"
                  placeholderTextColor={colors.placeholder}
                  style={[
                    styles.editInput,
                    {
                      color: colors.ink,
                      borderColor: colors.border,
                    },
                  ]}
                />

                <TextInput
                  value={bio}
                  onChangeText={setBio}
                  placeholder="Bio"
                  placeholderTextColor={colors.placeholder}
                  style={[
                    styles.editInput,
                    {
                      color: colors.ink,
                      borderColor: colors.border,
                    },
                  ]}
                />

                <Pressable
                  onPress={saveProfile}
                  style={[
                    styles.saveButton,
                    { backgroundColor: colors.ink },
                  ]}
                >
                  <Text
                    style={[
                      styles.saveText,
                      { color: colors.background },
                    ]}
                  >
                    Save changes
                  </Text>
                </Pressable>
              </View>
            )}

            {/* STATS */}
            <View
              style={[
                styles.stats,
                { borderColor: colors.border },
              ]}
            >
              <View>
                <Text
                  style={[
                    styles.statValue,
                    { color: colors.ink },
                  ]}
                >
                  {profilePosts.length}
                </Text>

                <Text
                  style={[
                    styles.statLabel,
                    { color: colors.mutedForeground },
                  ]}
                >
                  Posts
                </Text>
              </View>

              <View>
                <Text
                  style={[
                    styles.statValue,
                    { color: colors.ink },
                  ]}
                >
                  0
                </Text>

                <Text
                  style={[
                    styles.statLabel,
                    { color: colors.mutedForeground },
                  ]}
                >
                  Followers
                </Text>
              </View>

              <View>
                <Text
                  style={[
                    styles.statValue,
                    { color: colors.ink },
                  ]}
                >
                  0
                </Text>

                <Text
                  style={[
                    styles.statLabel,
                    { color: colors.mutedForeground },
                  ]}
                >
                  Following
                </Text>
              </View>
            </View>

            {/* TABS */}
            <View
              style={[
                styles.tabs,
                { borderColor: colors.border },
              ]}
            >
              <Pressable
                onPress={() => {
                  setActiveTab('posts');
                  setSelectedPostId(null);
                }}
                style={[
                  styles.tab,
                  activeTab === 'posts' && {
                    borderBottomColor: colors.coral,
                  },
                ]}
              >
                <Feather
                  name="grid"
                  size={17}
                  color={
                    activeTab === 'posts'
                      ? colors.coral
                      : colors.mutedForeground
                  }
                />

                <Text
                  style={[
                    styles.tabText,
                    {
                      color:
                        activeTab === 'posts'
                          ? colors.coral
                          : colors.mutedForeground,
                    },
                  ]}
                >
                  Posts
                </Text>
              </Pressable>

              <Pressable
                onPress={() => {
                  setActiveTab('saved');
                  setSelectedPostId(null);
                }}
                style={[
                  styles.tab,
                  activeTab === 'saved' && {
                    borderBottomColor: colors.coral,
                  },
                ]}
              >
                <Feather
                  name="bookmark"
                  size={17}
                  color={
                    activeTab === 'saved'
                      ? colors.coral
                      : colors.mutedForeground
                  }
                />

                <Text
                  style={[
                    styles.tabText,
                    {
                      color:
                        activeTab === 'saved'
                          ? colors.coral
                          : colors.mutedForeground,
                    },
                  ]}
                >
                  Saved
                </Text>
              </Pressable>
            </View>
          </View>
        }
        renderItem={({ item, index }) => (
          <ProfileGridItem
            post={item}
            index={index}
            onPress={() =>
              setSelectedPostId((current) =>
                current === item.id ? null : item.id,
              )
            }
          />
        )}
        ListFooterComponent={
          selectedPost ? (
            <View style={styles.selectedPost}>
              <Text
                style={[
                  styles.selectedLabel,
                  { color: colors.mutedForeground },
                ]}
              >
                Selected post
              </Text>

              <PostCard
                post={selectedPost}
                onLike={() =>
                  toggleLike(selectedPost.id)
                }
                onComment={() => undefined}
                onShare={() => undefined}
                onSave={() =>
                  toggleSave(selectedPost.id)
                }
              />
            </View>
          ) : null
        }
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather
              name={
                activeTab === 'saved'
                  ? 'bookmark'
                  : 'edit-3'
              }
              size={25}
              color={colors.coral}
            />

            <Text
              style={[
                styles.emptyTitle,
                { color: colors.ink },
              ]}
            >
              {activeTab === 'saved'
                ? 'Nothing saved yet'
                : 'Your story starts here'}
            </Text>

            <Text
              style={[
                styles.emptyText,
                { color: colors.mutedForeground },
              ]}
            >
              {activeTab === 'saved'
                ? 'Save posts that you want to come back to.'
                : 'Share a thought and let your people in.'}
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    paddingHorizontal: 18,
  },

  topBar: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },

  topActions: {
    flexDirection: 'row',
    gap: 7,
  },

  profileHead: {
    alignItems: 'center',
    paddingTop: 26,
  },

  profileAvatarRing: {
    borderRadius: 49,
    borderWidth: 1.5,
    padding: 4,
  },

  profileName: {
    fontFamily: 'Inter_700Bold',
    fontSize: 22,
    letterSpacing: -0.5,
    marginTop: 13,
  },

  profileHandle: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    marginTop: 4,
  },

  profileBio: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    marginTop: 13,
    maxWidth: 250,
    textAlign: 'center',
  },

  editButton: {
    alignItems: 'center',
    borderRadius: 11,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 7,
    marginTop: 16,
    paddingHorizontal: 13,
    paddingVertical: 8,
  },

  editText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 11,
  },

  editCard: {
    borderRadius: 16,
    borderWidth: 1,
    gap: 10,
    marginTop: 18,
    padding: 13,
  },

  editInput: {
    borderRadius: 10,
    borderWidth: 1,
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    height: 42,
    paddingHorizontal: 12,
  },

  saveButton: {
    alignItems: 'center',
    borderRadius: 10,
    paddingVertical: 11,
  },

  saveText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 12,
  },

  stats: {
    borderBottomWidth: 1,
    borderTopWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 25,
    paddingVertical: 16,
  },

  statValue: {
    fontFamily: 'Inter_700Bold',
    fontSize: 17,
    textAlign: 'center',
  },

  statLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    marginTop: 4,
    textAlign: 'center',
  },

  tabs: {
    borderBottomWidth: 1,
    flexDirection: 'row',
    marginBottom: 16,
    marginTop: 11,
  },

  tab: {
    alignItems: 'center',
    borderBottomWidth: 2,
    borderColor: 'transparent',
    flex: 1,
    flexDirection: 'row',
    gap: 7,
    justifyContent: 'center',
    paddingBottom: 12,
    paddingTop: 10,
  },

  tabText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
  },

  gridRow: {
    gap: 6,
    marginBottom: 6,
  },

  gridItem: {
    aspectRatio: 1,
    borderRadius: 10,
    flex: 1,
    maxWidth: '33.33%',
    overflow: 'hidden',
    position: 'relative',
  },

  gridImage: {
    height: '100%',
    width: '100%',
  },

  textGrid: {
    flex: 1,
    justifyContent: 'center',
    padding: 10,
  },

  textGridCopy: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 11,
    lineHeight: 15,
  },

  videoGrid: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
  },

  videoBadge: {
    alignItems: 'center',
    borderRadius: 10,
    height: 20,
    justifyContent: 'center',
    position: 'absolute',
    right: 6,
    top: 6,
    width: 20,
  },

  selectedPost: {
    marginTop: 22,
  },

  selectedLabel: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 11,
    marginBottom: 9,
  },

  empty: {
    alignItems: 'center',
    paddingHorizontal: 26,
    paddingVertical: 36,
  },

  emptyTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 16,
    marginTop: 12,
  },

  emptyText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    lineHeight: 18,
    marginTop: 7,
    textAlign: 'center',
  },
});