import { Feather, Ionicons } from '@expo/vector-icons';
import React from 'react';
import { FlatList, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar, EmptyState, IconButton, uiStyles } from '@/components/ConnectUpUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export default function NotificationsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { notifications, markNotificationsRead } = useApp();
  const unread = notifications.filter((item) => !item.read).length;
  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + (Platform.OS === 'web' ? 94 : 88) }}
        ListHeaderComponent={
          <View style={{ paddingTop: insets.top + 10 }}>
            <View style={styles.header}><View><Text style={[styles.heading, { color: colors.ink }]}>Notifications</Text><Text style={[styles.subheading, { color: colors.mutedForeground }]}>{unread ? `${unread} new updates` : 'You’re all caught up'}</Text></View>{unread ? <IconButton name="check" onPress={markNotificationsRead} color={colors.coral} testID="mark-all-read" /> : <Ionicons name="checkmark-circle-outline" size={24} color={colors.mintDark} />}</View>
            <View style={[styles.divider, { backgroundColor: colors.border }]} />
          </View>
        }
        renderItem={({ item, index }) => (
          <Pressable onPress={markNotificationsRead} style={({ pressed }) => [styles.notification, !item.read && { backgroundColor: colors.card }, pressed && uiStyles.pressed]} testID={`notification-${item.id}`}>
            <Avatar initials={item.initials} index={index + 1} size={43} />
            <View style={styles.notificationCopy}><Text style={[styles.notificationText, { color: colors.ink }]}><Text style={styles.bold}>{item.actor}</Text> {item.text}</Text><Text style={[styles.time, { color: colors.mutedForeground }]}>{item.time}</Text></View>
            <View style={[styles.kindIcon, { backgroundColor: item.kind === 'like' ? colors.sand : colors.mint }]}><Feather name={item.kind === 'like' ? 'heart' : item.kind === 'comment' ? 'message-circle' : 'user-plus'} size={15} color={colors.ink} /></View>
          </Pressable>
        )}
        ListEmptyComponent={<EmptyState title="No notifications" message="New likes, comments, and follows will appear here." icon="bell" />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 18 },
  header: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' },
  heading: { fontFamily: 'Inter_700Bold', fontSize: 29, letterSpacing: -1 },
  subheading: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 6 },
  divider: { height: 1, marginVertical: 22 },
  notification: { alignItems: 'center', borderRadius: 18, flexDirection: 'row', marginBottom: 8, padding: 12 },
  notificationCopy: { flex: 1, marginLeft: 12, paddingRight: 8 },
  notificationText: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 19 },
  bold: { fontFamily: 'Inter_700Bold' },
  time: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 5 },
  kindIcon: { alignItems: 'center', borderRadius: 15, height: 30, justifyContent: 'center', width: 30 },
});