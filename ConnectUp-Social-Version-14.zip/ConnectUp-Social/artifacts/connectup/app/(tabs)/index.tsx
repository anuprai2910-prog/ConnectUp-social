import { Feather, Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert,
  Share,
  FlatList,
  Platform,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar, IconButton, PostCard, Wordmark, uiStyles } from '@/components/ConnectUpUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';



export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { posts, toggleLike, toggleSave, notifications, user, stories, loadStories, isAuthenticated } = useApp();
  const [refreshing, setRefreshing] = useState(false);
  useEffect(() => { loadStories(); }, [isAuthenticated]);
  const activeStories = stories.filter((s) => new Date(s.expiresAt).getTime() > Date.now());
  const people = Array.from(new Map(activeStories.map((s) => [s.username, s])).values());
  const homeStories = [{ initials: user.initials, name: 'Your story', index: 0, id: activeStories.find((s) => s.username === user.handle)?.id }, ...people.filter(s=>s.username!==user.handle).map((s,i)=>({ initials: s.username.slice(0,2).toUpperCase(), name: s.username, index: i+1, id:s.id }))];
  const unreadCount = notifications.filter((item) => !item.read).length;
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 550);
  }, []);

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.coral} />}
        scrollEnabled={posts.length > 0}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + (Platform.OS === 'web' ? 94 : 88) }}
        ListHeaderComponent={
          <View style={{ paddingTop: insets.top + 10 }}>
            <View style={styles.topBar}>
              <Wordmark />
              <View style={styles.topActions}>
                <IconButton name="search" onPress={() => router.push('/(tabs)/search')} testID="home-search" />
                <IconButton name="message-circle" onPress={() => router.push('/messages')} testID="home-messages" />
                <Pressable onPress={() => router.push('/(tabs)/notifications')} style={({ pressed }) => [styles.bellButton, pressed && uiStyles.pressed]} testID="home-notifications">
                  <Feather name="bell" size={20} color={colors.ink} />
                  {unreadCount > 0 && <View style={[styles.badge, { backgroundColor: colors.coral }]}><Text style={[styles.badgeText, { color: colors.background }]}>{unreadCount}</Text></View>}
                </Pressable>
              </View>
            </View>
            <View style={styles.greeting}>
              <Text style={[styles.kicker, { color: colors.coral }]}>WEDNESDAY, SEPTEMBER 09</Text>
              <Text style={[styles.heading, { color: colors.ink }]}>Good morning, {user.name.split(/\s+/)[0] ?? 'there'}</Text>
              <Text style={[styles.subheading, { color: colors.mutedForeground }]}>Here’s what your circle is sharing.</Text>
            </View>
            <FlatList
              data={homeStories}
              horizontal
              keyExtractor={(item) => item.name}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.storyList}
              renderItem={({ item, index }) => (
                <Pressable
                  style={styles.story}
                  onPress={() => item.id ? router.push({ pathname: '/stories', params: { id: item.id } }) : item.name === 'Your story' ? router.push('/story-create') : Alert.alert('No active story', `${item.name} has no active story right now.`)}
                  testID={`story-${item.name}`}
                >
                  <View style={[styles.storyRing, { borderColor: index === 0 ? colors.coral : colors.ink }]}>
                    <Avatar initials={item.initials} index={item.index} size={50} />
                    {index === 0 && <View style={[styles.storyPlus, { backgroundColor: colors.coral, borderColor: colors.background }]}><Ionicons name="add" size={12} color={colors.background} /></View>}
                  </View>
                  <Text style={[styles.storyName, { color: colors.mutedForeground }]}>{item.name}</Text>
                </Pressable>
              )}
            />
            <View style={styles.feedLabelRow}>
              <Text style={[styles.feedLabel, { color: colors.ink }]}>For you</Text>
              <View style={[styles.liveDot, { backgroundColor: colors.mint }]} />
              <Text style={[styles.liveText, { color: colors.mutedForeground }]}>Latest from your circle</Text>
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <PostCard
            post={item}
            onLike={() => toggleLike(item.id)}
            onComment={() => router.push({ pathname: '/comments', params: { postId: item.id } })}
            onShare={async () => {
              try { await Share.share({ message: `${item.author}: ${item.text}` }); }
              catch { Alert.alert('Share failed', 'This post could not be shared right now.'); }
            }}
            onSave={() => toggleSave(item.id)}
          />
        )}
        ListEmptyComponent={
          <View style={{ paddingHorizontal: 16 }}><Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Your feed is quiet right now.</Text></View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  topBar: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 18 },
  topActions: { alignItems: 'center', flexDirection: 'row', gap: 9 },
  bellButton: { alignItems: 'center', height: 32, justifyContent: 'center', position: 'relative', width: 32 },
  badge: { alignItems: 'center', borderRadius: 8, height: 16, justifyContent: 'center', minWidth: 16, paddingHorizontal: 3, position: 'absolute', right: -1, top: -3 },
  badgeText: { fontFamily: 'Inter_700Bold', fontSize: 9 },
  greeting: { paddingHorizontal: 18, paddingTop: 27 },
  kicker: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2 },
  heading: { fontFamily: 'Inter_700Bold', fontSize: 25, letterSpacing: -0.8, marginTop: 8 },
  subheading: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 5 },
  storyList: { gap: 16, paddingHorizontal: 18, paddingVertical: 24 },
  story: { alignItems: 'center', width: 58 },
  storyRing: { alignItems: 'center', borderRadius: 34, borderWidth: 1.5, padding: 3 },
  storyPlus: { alignItems: 'center', borderRadius: 9, borderWidth: 2, bottom: -2, height: 18, justifyContent: 'center', position: 'absolute', right: -2, width: 18 },
  storyName: { fontFamily: 'Inter_500Medium', fontSize: 11, marginTop: 7 },
  feedLabelRow: { alignItems: 'center', flexDirection: 'row', gap: 7, paddingBottom: 12, paddingHorizontal: 18 },
  feedLabel: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  liveDot: { borderRadius: 3, height: 6, marginLeft: 2, width: 6 },
  liveText: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 14, padding: 24, textAlign: 'center' },
});
