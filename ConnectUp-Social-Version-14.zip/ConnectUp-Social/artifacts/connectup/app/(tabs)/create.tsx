import * as ImagePicker from 'expo-image-picker';
import { Feather, Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Image, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { feedImages, IconButton, PostMediaPreview, uiStyles, Wordmark } from '@/components/ConnectUpUI';
import type { PostImage, PostMedia } from '@/context/AppContext';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export default function CreatePostScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addPost, user } = useApp();
  const [text, setText] = useState('');
  const [image, setImage] = useState<PostImage>('none');
  const [selectedMedia, setSelectedMedia] = useState<PostMedia>(null);
  const [error, setError] = useState('');

  const chooseMedia = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      setError('Allow photo access to choose a visual from your device.');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images', 'videos'],
      allowsEditing: false,
      quality: 0.9,
    });

    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    setSelectedMedia({
      uri: asset.uri,
      type: asset.type === 'video' ? 'video' : 'image',
      fileName: asset.fileName,
    });
    setImage('none');
    setError('');
  };

  const selectSample = (option: PostImage) => {
    setImage(option);
    setSelectedMedia(null);
    setError('');
  };

  const publish = () => {
    if (!text.trim()) {
      setError('Add a caption before publishing.');
      return;
    }
    addPost(text.trim(), image, selectedMedia);
    setText('');
    setImage('none');
    setSelectedMedia(null);
    setError('');
    router.replace('/(tabs)');
  };

  const cancel = () => {
    setText('');
    setImage('none');
    setSelectedMedia(null);
    setError('');
    router.replace('/(tabs)');
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        bottomOffset={80}
        contentContainerStyle={{ paddingTop: insets.top + 12, paddingBottom: insets.bottom + 100 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Pressable onPress={cancel} style={({ pressed }) => [styles.cancelButton, pressed && uiStyles.pressed]} testID="cancel-post">
            <Text style={[styles.cancelText, { color: colors.mutedForeground }]}>Cancel</Text>
          </Pressable>
          <Wordmark />
          <Pressable onPress={publish} style={({ pressed }) => [styles.publishButton, { backgroundColor: text.trim() ? colors.coral : colors.muted }, pressed && uiStyles.pressed]} testID="publish-post">
            <Text style={[styles.publishText, { color: text.trim() ? colors.background : colors.mutedForeground }]}>Publish</Text>
          </Pressable>
        </View>

        <View style={styles.titleWrap}>
          <Text style={[styles.kicker, { color: colors.coral }]}>MAKE IT YOURS</Text>
          <Text style={[styles.heading, { color: colors.ink }]}>Share a moment</Text>
          <Text style={[styles.subheading, { color: colors.mutedForeground }]}>What’s on your mind, {user.name.split(/\s+/)[0]}?</Text>
        </View>

        <View style={[styles.composer, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.composerTop}>
            <View style={[styles.avatar, { backgroundColor: colors.sand }]}>
              <Text style={[styles.avatarText, { color: colors.coral }]}>{user.initials}</Text>
            </View>
            <View>
              <Text style={[styles.userName, { color: colors.ink }]}>{user.name}</Text>
              <Text style={[styles.userHandle, { color: colors.mutedForeground }]}>@{user.handle}</Text>
            </View>
          </View>
          <TextInput
            value={text}
            onChangeText={(value) => {
              setText(value);
              if (error) setError('');
            }}
            multiline
            placeholder="Start with something real..."
            placeholderTextColor={colors.placeholder}
            style={[styles.textInput, { color: colors.ink }]}
            maxLength={240}
            testID="post-text"
          />
          <View style={styles.composerFooter}>
            <Text style={[styles.characterCount, { color: colors.placeholder }]}>{text.length}/240</Text>
            <Feather name="edit-3" size={17} color={colors.mutedForeground} />
          </View>
        </View>

        {error ? <Text style={[styles.error, { color: colors.coral }]}>{error}</Text> : null}

        <Text style={[styles.sectionTitle, { color: colors.ink }]}>Add a visual</Text>
        {selectedMedia ? (
          <View style={[styles.mediaCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <PostMediaPreview media={selectedMedia} height={190} />
            <View style={styles.mediaMeta}>
              <View style={styles.mediaMetaCopy}>
                <Ionicons name={selectedMedia.type === 'video' ? 'videocam-outline' : 'image-outline'} size={16} color={colors.coral} />
                <Text style={[styles.mediaType, { color: colors.ink }]}>{selectedMedia.type === 'video' ? 'Video selected' : 'Photo selected'}</Text>
              </View>
              <Pressable onPress={() => setSelectedMedia(null)} style={({ pressed }) => [styles.removeMedia, pressed && uiStyles.pressed]} testID="remove-media">
                <Feather name="x" size={17} color={colors.mutedForeground} />
                <Text style={[styles.removeText, { color: colors.mutedForeground }]}>Remove</Text>
              </Pressable>
            </View>
          </View>
        ) : (
          <Pressable onPress={chooseMedia} style={({ pressed }) => [styles.pickerButton, { backgroundColor: colors.card, borderColor: colors.border }, pressed && uiStyles.pressed]} testID="choose-media">
            <View style={[styles.pickerIcon, { backgroundColor: colors.sand }]}>
              <Ionicons name="images-outline" size={23} color={colors.coral} />
            </View>
            <View style={styles.pickerCopy}>
              <Text style={[styles.pickerTitle, { color: colors.ink }]}>Choose from device</Text>
              <Text style={[styles.pickerSubtitle, { color: colors.mutedForeground }]}>Select a photo or video from your library</Text>
            </View>
            <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
          </Pressable>
        )}

        <Text style={[styles.sampleLabel, { color: colors.mutedForeground }]}>Or try a HITSUN sample</Text>
        <View style={styles.imageOptions}>
          {(['none', 'city', 'cafe'] as PostImage[]).map((option) => (
            <Pressable
              key={option}
              onPress={() => selectSample(option)}
              style={({ pressed }) => [styles.imageOption, { borderColor: image === option && !selectedMedia ? colors.coral : colors.border, backgroundColor: image === option && !selectedMedia ? colors.sand : colors.card }, pressed && uiStyles.pressed]}
              testID={`image-${option}`}
            >
              {option === 'none' ? <Feather name="type" size={20} color={image === option && !selectedMedia ? colors.coral : colors.mutedForeground} /> : <Image source={feedImages[option]} style={styles.optionImage} />}
              {image === option && !selectedMedia && <View style={[styles.selectedMark, { backgroundColor: colors.coral }]}><Ionicons name="checkmark" size={12} color={colors.background} /></View>}
            </Pressable>
          ))}
        </View>

        <View style={[styles.tip, { backgroundColor: colors.mint }]}>
          <Feather name="heart" size={17} color={colors.ink} />
          <Text style={[styles.tipText, { color: colors.ink }]}>The best posts don’t need to be perfect. Just yours.</Text>
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 18 },
  cancelButton: { minWidth: 62, paddingVertical: 9 },
  cancelText: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  publishButton: { borderRadius: 12, paddingHorizontal: 14, paddingVertical: 9 },
  publishText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  titleWrap: { paddingHorizontal: 18, paddingTop: 40 },
  kicker: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2 },
  heading: { fontFamily: 'Inter_700Bold', fontSize: 29, letterSpacing: -1, marginTop: 8 },
  subheading: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 6 },
  composer: { borderRadius: 21, borderWidth: 1, marginHorizontal: 18, marginTop: 25, padding: 16 },
  composerTop: { alignItems: 'center', flexDirection: 'row' },
  avatar: { alignItems: 'center', borderRadius: 21, height: 42, justifyContent: 'center', width: 42 },
  avatarText: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  userName: { fontFamily: 'Inter_600SemiBold', fontSize: 13, marginLeft: 11 },
  userHandle: { fontFamily: 'Inter_400Regular', fontSize: 11, marginLeft: 11, marginTop: 3 },
  textInput: { fontFamily: 'Inter_400Regular', fontSize: 17, lineHeight: 25, minHeight: 145, paddingTop: 22, textAlignVertical: 'top' },
  composerFooter: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' },
  characterCount: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  error: { fontFamily: 'Inter_500Medium', fontSize: 12, marginHorizontal: 18, marginTop: 10 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 16, marginHorizontal: 18, marginTop: 30 },
  pickerButton: { alignItems: 'center', borderRadius: 18, borderWidth: 1, flexDirection: 'row', marginHorizontal: 18, marginTop: 13, padding: 14 },
  pickerIcon: { alignItems: 'center', borderRadius: 13, height: 46, justifyContent: 'center', width: 46 },
  pickerCopy: { flex: 1, marginLeft: 12 },
  pickerTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  pickerSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 4 },
  mediaCard: { borderRadius: 18, borderWidth: 1, marginHorizontal: 18, marginTop: 13, overflow: 'hidden' },
  mediaMeta: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', padding: 12 },
  mediaMetaCopy: { alignItems: 'center', flexDirection: 'row', gap: 7 },
  mediaType: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  removeMedia: { alignItems: 'center', flexDirection: 'row', gap: 5 },
  removeText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  sampleLabel: { fontFamily: 'Inter_500Medium', fontSize: 11, marginHorizontal: 18, marginTop: 20 },
  imageOptions: { flexDirection: 'row', gap: 12, marginHorizontal: 18, marginTop: 10 },
  imageOption: { alignItems: 'center', borderRadius: 15, borderWidth: 1.5, height: 72, justifyContent: 'center', overflow: 'hidden', position: 'relative', width: 72 },
  optionImage: { height: '100%', width: '100%' },
  selectedMark: { alignItems: 'center', borderRadius: 10, height: 20, justifyContent: 'center', position: 'absolute', right: 5, top: 5, width: 20 },
  tip: { alignItems: 'center', borderRadius: 15, flexDirection: 'row', gap: 9, marginHorizontal: 18, marginTop: 30, padding: 14 },
  tipText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 12, lineHeight: 18 },
});