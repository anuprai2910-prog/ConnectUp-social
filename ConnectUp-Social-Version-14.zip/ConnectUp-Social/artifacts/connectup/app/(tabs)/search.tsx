import { Feather } from '@expo/vector-icons';
import React, { useMemo, useState } from 'react';
import { router } from 'expo-router';
import { FlatList, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { feedImages, Avatar, EmptyState, PostCard, uiStyles } from '@/components/ConnectUpUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export default function SearchScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { posts, profiles, isFollowing, toggleFollow, toggleLike, toggleSave } = useApp();
  const [query, setQuery] = useState('');
  const normalized = query.trim().toLowerCase();
  const filteredPeople = useMemo(() => profiles.filter((person) => `${person.name} ${person.handle}`.toLowerCase().includes(normalized)), [normalized, profiles]);
  const filteredPosts = useMemo(() => posts.filter((post) => `${post.author} ${post.handle} ${post.text}`.toLowerCase().includes(normalized)), [normalized, posts]);

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <FlatList
        data={normalized ? filteredPosts : []}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + (Platform.OS === 'web' ? 94 : 88) }}
        ListHeaderComponent={
          <View style={{ paddingTop: insets.top + 10 }}>
            <Text style={[styles.heading, { color: colors.ink }]}>Discover</Text>
            <Text style={[styles.subheading, { color: colors.mutedForeground }]}>Find people and conversations worth following.</Text>
            <View style={[styles.searchBar, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Feather name="search" size={18} color={colors.mutedForeground} />
              <TextInput value={query} onChangeText={setQuery} placeholder="Search people or posts" placeholderTextColor={colors.placeholder} style={[styles.searchInput, { color: colors.ink }]} testID="search-input" />
              {query ? <Pressable onPress={() => setQuery('')} style={({ pressed }) => [pressed && uiStyles.pressed]}><Feather name="x-circle" size={18} color={colors.mutedForeground} /></Pressable> : null}
            </View>
            {!normalized ? (
              <View>
                <Text style={[styles.sectionTitle, { color: colors.ink }]}>People you may know</Text>
                <View style={[styles.peopleCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  {profiles.map((person, index) => (
                  <View key={person.handle} style={[styles.personRow, { borderColor: colors.border }]}>
                      <Avatar initials={person.initials} image={person.avatarImage && person.avatarImage !== 'none' ? feedImages[person.avatarImage] : undefined} index={index + 1} size={40} />
                      <View style={styles.personInfo}><Text style={[styles.personName, { color: colors.ink }]}>{person.name}</Text><Text style={[styles.personHandle, { color: colors.mutedForeground }]}>@{person.handle} · {person.followers} followers</Text></View>
                      <View style={styles.actionRow}><Pressable onPress={() => toggleFollow(person.handle)} style={({ pressed }) => [styles.followButton, { backgroundColor: isFollowing(person.handle) ? colors.ink : colors.card, borderColor: isFollowing(person.handle) ? colors.ink : colors.borderStrong }, pressed && uiStyles.pressed]} testID={`follow-${person.handle}`}><Text style={[styles.followText, { color: isFollowing(person.handle) ? colors.background : colors.ink }]}>{isFollowing(person.handle) ? 'Following' : 'Follow'}</Text></Pressable><Pressable onPress={() => router.push({pathname:'/messages',params:{handle:person.handle}})} style={[styles.messageButton,{borderColor:colors.borderStrong}]}><Feather name="message-circle" size={15} color={colors.ink}/></Pressable></View>
                    </View>
                  ))}
                </View>
                <Text style={[styles.sectionTitle, { color: colors.ink }]}>Explore by interest</Text>
                <View style={styles.tags}>
                  {['slow mornings', 'creative work', 'city walks', 'good food'].map((tag, index) => (
                    <Pressable key={tag} onPress={() => setQuery(tag.split(' ')[0])} style={[styles.tag, { backgroundColor: index % 2 === 0 ? colors.sand : colors.mint }]}><Text style={[styles.tagText, { color: colors.ink }]}>#{tag}</Text></Pressable>
                  ))}
                </View>
              </View>
            ) : (
              <View>
                <Text style={[styles.sectionTitle, { color: colors.ink }]}>People</Text>
                {filteredPeople.length ? filteredPeople.map((person, index) => (
                  <View key={person.handle} style={styles.resultPerson}><Avatar initials={person.initials} image={person.avatarImage && person.avatarImage !== 'none' ? feedImages[person.avatarImage] : undefined} index={index + 1} size={40} /><View style={styles.personInfo}><Text style={[styles.personName, { color: colors.ink }]}>{person.name}</Text><Text style={[styles.personHandle, { color: colors.mutedForeground }]}>@{person.handle} · {person.followers} followers</Text></View><View style={styles.actionRow}><Pressable onPress={() => toggleFollow(person.handle)} style={({ pressed }) => [styles.followButton, { backgroundColor: isFollowing(person.handle) ? colors.ink : colors.card, borderColor: isFollowing(person.handle) ? colors.ink : colors.borderStrong }, pressed && uiStyles.pressed]} testID={`follow-result-${person.handle}`}><Text style={[styles.followText, { color: isFollowing(person.handle) ? colors.background : colors.ink }]}>{isFollowing(person.handle) ? 'Following' : 'Follow'}</Text></Pressable><Pressable onPress={() => router.push({pathname:'/messages',params:{handle:person.handle}})} style={[styles.messageButton,{borderColor:colors.borderStrong}]}><Feather name="message-circle" size={15} color={colors.ink}/></Pressable></View></View>
                )) : <Text style={[styles.noResults, { color: colors.mutedForeground }]}>No people found.</Text>}
                <Text style={[styles.sectionTitle, { color: colors.ink }]}>Posts</Text>
              </View>
            )}
          </View>
        }
        renderItem={({ item }) => <PostCard post={item} onLike={() => toggleLike(item.id)} onComment={() => undefined} onShare={() => undefined} onSave={() => toggleSave(item.id)} />}
        ListEmptyComponent={normalized ? <View style={styles.emptyWrap}><EmptyState title="Nothing here yet" message="Try a different name, handle, or phrase." icon="search" /></View> : null}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 18 },
  heading: { fontFamily: 'Inter_700Bold', fontSize: 30, letterSpacing: -1 },
  subheading: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 6 },
  searchBar: { alignItems: 'center', borderRadius: 15, borderWidth: 1, flexDirection: 'row', gap: 9, marginTop: 24, paddingHorizontal: 14 },
  searchInput: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 14, height: 48 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 16, marginBottom: 12, marginTop: 29 },
  peopleCard: { borderRadius: 20, borderWidth: 1, paddingHorizontal: 14 },
  personRow: { alignItems: 'center', borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: 'row', paddingVertical: 13 },
  personInfo: { flex: 1, marginLeft: 11 },
  personName: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  personHandle: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 3 },
  followButton: { borderRadius: 10, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 7 },
  followText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  actionRow: { alignItems: 'center', flexDirection: 'row', gap: 6 },
  messageButton: { alignItems: 'center', borderRadius: 10, borderWidth: 1, height: 32, justifyContent: 'center', width: 32 },
  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  tag: { borderRadius: 13, paddingHorizontal: 14, paddingVertical: 10 },
  tagText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  resultPerson: { alignItems: 'center', flexDirection: 'row', paddingBottom: 14 },
  noResults: { fontFamily: 'Inter_400Regular', fontSize: 13 },
  emptyWrap: { paddingHorizontal: 0 },
});