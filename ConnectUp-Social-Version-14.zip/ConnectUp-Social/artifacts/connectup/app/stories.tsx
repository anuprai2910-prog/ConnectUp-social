import { Feather, Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export default function StoriesScreen(){
  const colors=useColors(); const insets=useSafeAreaInsets(); const {stories,user,viewStory,reactToStory,removeStoryReaction,getStoryViewers}=useApp();
  const params=useLocalSearchParams<{id?:string}>();
  const activeList=useMemo(()=>stories.filter(s=>new Date(s.expiresAt).getTime()>Date.now()),[stories]);
  const [index,setIndex]=useState(Math.max(0,activeList.findIndex(s=>s.id===params.id)));
  const story=activeList[index]; const [viewers,setViewers]=useState<{username:string;viewedAt:string}[]>([]);
  useEffect(()=>{if(story)viewStory(story.id);},[story?.id]);
  if(!story) return <View style={[styles.empty,{backgroundColor:colors.background,paddingTop:insets.top}]}><Text style={[styles.emptyTitle,{color:colors.ink}]}>No active stories</Text><Pressable onPress={()=>router.back()}><Text style={{color:colors.coral}}>Go back</Text></Pressable></View>;
  const isMine=story.username===user.handle;
  const next=()=>index<activeList.length-1?setIndex(index+1):router.back();
  const previous=()=>index>0&&setIndex(index-1);
  const toggleReaction=()=>story.reaction?removeStoryReaction(story.id):reactToStory(story.id,'❤️');
  const showViewers=async()=>{if(!isMine)return; const v=await getStoryViewers(story.id); setViewers(v); Alert.alert('Viewers',v.length? v.map(x=>`@${x.username}`).join('\n'):'No viewers yet.');};
  return <View style={[styles.screen,{backgroundColor:'#111'}]}>
    <View style={[styles.progressRow,{paddingTop:insets.top+8}]}>{activeList.map((s,i)=><View key={s.id} style={styles.progress}><View style={[styles.progressFill,{width:i<index?'100%':i===index?'100%':'0%',backgroundColor:'#fff'}]}/></View>)}</View>
    <View style={[styles.header,{top:insets.top+26}]}><Pressable onPress={()=>router.back()} style={styles.close}><Feather name="x" size={24} color="#fff"/></Pressable><View style={{flex:1}}><Text style={styles.handle}>@{story.username}</Text><Text style={styles.time}>{Math.max(1,Math.ceil((new Date(story.expiresAt).getTime()-Date.now())/3600000))}h left</Text></View><Pressable onPress={showViewers}><Feather name="eye" size={20} color="#fff"/></Pressable></View>
    <Pressable style={styles.tapLeft} onPress={previous}/><Pressable style={styles.tapRight} onPress={next}/>
    {story.mediaUrl ? <Image source={{uri:story.mediaUrl}} style={styles.media} resizeMode="contain"/> : <View style={styles.textStory}><Text style={styles.storyText}>{story.text}</Text></View>}
    {story.mediaUrl && story.text ? <View style={styles.caption}><Text style={styles.captionText}>{story.text}</Text></View>:null}
    <View style={[styles.bottom,{paddingBottom:insets.bottom+14}]}><Pressable onPress={toggleReaction} style={styles.reaction}><Text style={{fontSize:26}}>{story.reaction||'🤍'}</Text></Pressable>{isMine?<Text style={styles.hint}>{viewers.length?'':'Tap eye to see viewers'}</Text>:<Text style={styles.hint}>React to this story</Text>}<Pressable onPress={next}><Ionicons name="chevron-forward" size={28} color="#fff"/></Pressable></View>
  </View>;
}
const styles=StyleSheet.create({screen:{flex:1},empty:{flex:1,alignItems:'center',justifyContent:'center',gap:14},emptyTitle:{fontFamily:'Inter_700Bold',fontSize:20},progressRow:{flexDirection:'row',gap:4,paddingHorizontal:8},progress:{backgroundColor:'rgba(255,255,255,.35)',borderRadius:4,flex:1,height:3,overflow:'hidden'},progressFill:{height:'100%'},header:{alignItems:'center',flexDirection:'row',left:14,position:'absolute',right:14,zIndex:5},close:{padding:8},handle:{color:'#fff',fontFamily:'Inter_700Bold',fontSize:13},time:{color:'rgba(255,255,255,.7)',fontSize:10,marginTop:2},tapLeft:{bottom:90,left:0,position:'absolute',top:80,width:'35%',zIndex:3},tapRight:{bottom:90,position:'absolute',right:0,top:80,width:'35%',zIndex:3},media:{height:'72%',marginTop:'18%',width:'100%'},textStory:{alignItems:'center',justifyContent:'center',marginTop:'25%',padding:30,flex:1},storyText:{color:'#fff',fontFamily:'Inter_700Bold',fontSize:30,lineHeight:38,textAlign:'center'},caption:{backgroundColor:'rgba(0,0,0,.55)',borderRadius:14,bottom:100,left:20,padding:12,position:'absolute',right:20},captionText:{color:'#fff',fontSize:14,textAlign:'center'},bottom:{alignItems:'center',bottom:0,flexDirection:'row',gap:12,justifyContent:'space-between,left:18,position:'absolute',right:18},reaction:{alignItems:'center',height:48,justifyContent:'center',width:48},hint:{color:'rgba(255,255,255,.75)',flex:1,fontSize:11,textAlign:'center'}});
