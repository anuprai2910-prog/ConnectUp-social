import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { FlatList, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar, IconButton, EmptyState, uiStyles } from '@/components/ConnectUpUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export default function CommentsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { postId } = useLocalSearchParams<{ postId?: string }>();
  const { posts, addComment } = useApp();
  const post = posts.find((item) => item.id === postId);
  const [text, setText] = useState('');

  const submit = () => {
    if (!post || !text.trim()) return;
    addComment(post.id, text.trim());
    setText('');
  };

  return (
    <KeyboardAvoidingView behavior="padding" keyboardVerticalOffset={0} style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={{ paddingTop: insets.top + 10 }}>
        <View style={styles.header}><IconButton name="x" onPress={() => router.back()} testID="comments-close" /><Text style={[styles.heading, { color: colors.ink }]}>Comments</Text><View style={styles.spacer} /></View>
      </View>
      {post ? (
        <FlatList
          data={post.comments}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingBottom: 16 }}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={<View style={[styles.context, { backgroundColor: colors.card, borderColor: colors.border }]}><Avatar initials={post.initials} size={36} index={post.id.length} /><View style={styles.contextCopy}><Text style={[styles.contextAuthor, { color: colors.ink }]}>{post.author}</Text><Text style={[styles.contextText, { color: colors.mutedForeground }]} numberOfLines={2}>{post.text}</Text></View></View>}
          renderItem={({ item, index }) => <View style={styles.comment}><Avatar initials={item.author.split(' ').map((part) => part[0] ?? '').join('').slice(0, 2)} size={38} index={index + 2} /><View style={[styles.commentBubble, { backgroundColor: colors.softCard }]}><Text style={[styles.commentAuthor, { color: colors.ink }]}>{item.author}</Text><Text style={[styles.commentText, { color: colors.ink }]}>{item.text}</Text><Text style={[styles.commentTime, { color: colors.mutedForeground }]}>{item.time}</Text></View></View>}
          ListEmptyComponent={<EmptyState title="Start the conversation" message="Be the first person to say something thoughtful." icon="message-circle" />}
        />
      ) : <EmptyState title="Post not found" message="This conversation is no longer available." icon="slash" />}
      <View style={[styles.inputDock, { backgroundColor: colors.background, borderTopColor: colors.border, paddingBottom: Math.max(insets.bottom, Platform.OS === 'web' ? 34 : 10) }]}>
        <TextInput value={text} onChangeText={setText} placeholder="Add a thoughtful reply..." placeholderTextColor={colors.placeholder} style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.ink }]} testID="comment-input" />
        <Pressable onPress={submit} disabled={!text.trim()} style={({ pressed }) => [styles.send, { backgroundColor: text.trim() ? colors.coral : colors.muted }, pressed && uiStyles.pressed]} testID="comment-submit"><Feather name="arrow-up" size={19} color={text.trim() ? colors.background : colors.mutedForeground} /></Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 18 },
  header: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', paddingBottom: 14 },
  heading: { fontFamily: 'Inter_700Bold', fontSize: 18 },
  spacer: { width: 32 },
  context: { alignItems: 'center', borderRadius: 16, borderWidth: 1, flexDirection: 'row', marginBottom: 18, padding: 12 },
  contextCopy: { flex: 1, marginLeft: 10 },
  contextAuthor: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  contextText: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 17, marginTop: 4 },
  comment: { alignItems: 'flex-start', flexDirection: 'row', marginBottom: 17 },
  commentBubble: { borderRadius: 15, marginLeft: 10, maxWidth: '80%', paddingHorizontal: 13, paddingVertical: 10 },
  commentAuthor: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  commentText: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 18, marginTop: 4 },
  commentTime: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 6 },
  inputDock: { alignItems: 'center', borderTopWidth: 1, flexDirection: 'row', gap: 9, paddingTop: 11 },
  input: { borderRadius: 14, borderWidth: 1, flex: 1, fontFamily: 'Inter_400Regular', fontSize: 13, height: 46, paddingHorizontal: 14 },
  send: { alignItems: 'center', borderRadius: 14, height: 46, justifyContent: 'center', width: 46 },
});