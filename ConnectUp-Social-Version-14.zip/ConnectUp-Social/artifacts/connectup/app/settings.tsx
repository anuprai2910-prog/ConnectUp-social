import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { IconButton, Wordmark } from '@/components/ConnectUpUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export default function SettingsScreen(){
 const colors=useColors(); const insets=useSafeAreaInsets(); const {settings,updateSettings,resetLocalData,signOut}=useApp();
 const row=(icon:any,title:string,subtitle:string,onPress?:()=>void,control?:React.ReactNode)=><Pressable onPress={onPress} style={[styles.row,{borderColor:colors.border}]}><View style={[styles.icon,{backgroundColor:colors.sand}]}><Feather name={icon} size={17} color={colors.ink}/></View><View style={styles.copy}><Text style={[styles.title,{color:colors.ink}]}>{title}</Text><Text style={[styles.sub,{color:colors.mutedForeground}]}>{subtitle}</Text></View>{control??<Feather name="chevron-right" size={18} color={colors.mutedForeground}/>}</Pressable>;
 return <ScrollView style={{backgroundColor:colors.background}} contentContainerStyle={{padding:18,paddingTop:insets.top+10,paddingBottom:insets.bottom+40}}><View style={styles.header}><IconButton name="arrow-left" onPress={()=>router.back()}/><Wordmark compact/><View style={{width:32}}/></View><Text style={[styles.heading,{color:colors.ink}]}>Settings</Text><Text style={[styles.subheading,{color:colors.mutedForeground}]}>Control your HITSUN experience.</Text><View style={styles.group}>
 {row('bell','Notifications','Likes, comments and follows',undefined,<Switch value={settings.notifications} onValueChange={v=>updateSettings({notifications:v})} trackColor={{true:colors.coral}}/>) }
 {row('lock','Private account','Control who can see your profile',undefined,<Switch value={settings.privateAccount} onValueChange={v=>updateSettings({privateAccount:v})} trackColor={{true:colors.coral}}/>) }
 {row('moon','Dark mode','Use the app theme preference',undefined,<Switch value={settings.darkMode} onValueChange={v=>updateSettings({darkMode:v})} trackColor={{true:colors.coral}}/>) }
 </View><Text style={[styles.section,{color:colors.ink}]}>Account</Text><View style={styles.group}>{row('user','Edit profile','Change your name and bio',()=>router.replace('/(tabs)/profile'))}{row('log-out','Sign out','End the current session',()=>{signOut();router.replace('/')})}{row('trash-2','Reset local data','Clear local posts, follows and settings',()=>Alert.alert('Reset local data?','This only clears data saved on this device.',[{text:'Cancel',style:'cancel'},{text:'Reset',style:'destructive',onPress:()=>resetLocalData()}]))}</View></ScrollView>;
}
const styles=StyleSheet.create({header:{alignItems:'center',flexDirection:'row',justifyContent:'space-between'},heading:{fontFamily:'Inter_700Bold',fontSize:32,letterSpacing:-1,marginTop:44},subheading:{fontFamily:'Inter_400Regular',fontSize:13,marginTop:7},group:{borderRadius:18,marginTop:22,overflow:'hidden'},row:{alignItems:'center',borderBottomWidth:1,flexDirection:'row',paddingVertical:15},icon:{alignItems:'center',borderRadius:12,height:38,justifyContent:'center',width:38},copy:{flex:1,marginLeft:12},title:{fontFamily:'Inter_600SemiBold',fontSize:14},sub:{fontFamily:'Inter_400Regular',fontSize:11,marginTop:3},section:{fontFamily:'Inter_700Bold',fontSize:16,marginTop:30}});
