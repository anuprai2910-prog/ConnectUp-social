import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Avatar, IconButton } from '@/components/ConnectUpUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export default function MessagesScreen() {
  const colors = useColors();
  const { handle } = useLocalSearchParams<{ handle?: string }>();
  const { user, profiles, messages, conversationWith, sendMessage, markConversationRead, deleteMessage } = useApp();
  const person = profiles.find((p) => p.handle === handle);
  const [text, setText] = useState('');
  const [selectedTab, setSelectedTab] = useState<'all' | 'unread'>('all');

  const chats = useMemo(() => {
    const handles = new Set<string>();
    messages.forEach((m) => {
      if (m.from === user.handle) handles.add(m.to);
      if (m.to === user.handle) handles.add(m.from);
    });
    return [...handles].map((chatHandle) => {
      const profile = profiles.find((p) => p.handle === chatHandle);
      const items = messages.filter((m) => (m.from === user.handle && m.to === chatHandle) || (m.from === chatHandle && m.to === user.handle));
      const last = items[items.length - 1];
      const unread = items.filter((m) => m.from === chatHandle && m.to === user.handle && !m.read).length;
      return { handle: chatHandle, name: profile?.name || chatHandle, initials: profile?.initials || chatHandle.slice(0, 2).toUpperCase(), online: !!profile?.online, last, unread };
    }).sort((a, b) => (b.last?.id || '').localeCompare(a.last?.id || ''));
  }, [messages, profiles, user.handle]);

  const visibleChats = selectedTab === 'unread' ? chats.filter((chat) => chat.unread > 0) : chats;
  useEffect(() => { if (handle) markConversationRead(handle); }, [handle]);

  if (!handle) {
    return (
      <View style={[styles.screen, { backgroundColor: colors.background }]}> 
        <View style={styles.inboxHeader}>
          <View><Text style={[styles.title, { color: colors.ink }]}>Messages</Text><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Your private conversations</Text></View>
          <Pressable onPress={() => router.back()} style={styles.headerButton}><Feather name="x" size={21} color={colors.ink} /></Pressable>
        </View>
        <View style={[styles.tabs, { borderColor: colors.border }]}>
          {(['all', 'unread'] as const).map((tab) => <Pressable key={tab} onPress={() => setSelectedTab(tab)} style={[styles.tab, selectedTab === tab && { backgroundColor: colors.ink }]}><Text style={[styles.tabText, { color: selectedTab === tab ? colors.background : colors.mutedForeground }]}>{tab === 'all' ? 'All chats' : 'Unread'}</Text></Pressable>)}
        </View>
        <FlatList
          data={visibleChats}
          keyExtractor={(item) => item.handle}
          contentContainerStyle={{ paddingBottom: 30, flexGrow: visibleChats.length ? 0 : 1 }}
          ListEmptyComponent={<View style={styles.empty}><Feather name="message-circle" size={38} color={colors.mutedForeground} /><Text style={[styles.emptyTitle, { color: colors.ink }]}>No conversations yet</Text><Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Open Search and tap the message icon to start a chat.</Text></View>}
          renderItem={({ item }) => <Pressable onPress={() => router.push({ pathname: '/messages', params: { handle: item.handle } })} style={({ pressed }) => [styles.chatRow, { borderColor: colors.border }, pressed && { opacity: 0.7 }]}>
            <View><Avatar initials={item.initials} size={48} /><View style={[styles.onlineDot, { backgroundColor: item.online ? '#2EBD72' : colors.muted }]} /></View>
            <View style={styles.chatCopy}><View style={styles.nameLine}><Text style={[styles.name, { color: colors.ink }]}>{item.name}</Text>{item.unread > 0 && <View style={[styles.badge, { backgroundColor: colors.coral }]}><Text style={[styles.badgeText, { color: colors.background }]}>{item.unread}</Text></View>}</View><Text numberOfLines={1} style={[styles.preview, { color: colors.mutedForeground }]}>{item.last?.from === user.handle ? 'You: ' : ''}{item.last?.text}</Text></View><Text style={[styles.chatTime, { color: colors.mutedForeground }]}>{item.last?.time}</Text>
          </Pressable>}
        />
      </View>
    );
  }

  const messagesForChat = conversationWith(handle);
  const submit = () => { if (!text.trim()) return; sendMessage(handle, text); setText(''); };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={styles.wrap}>
        <View style={styles.header}>
          <IconButton name="arrow-left" onPress={() => router.back()} /><View><Avatar initials={person?.initials || handle.slice(0, 2).toUpperCase()} size={38} /><View style={[styles.onlineDot, styles.headerDot, { backgroundColor: person?.online ? '#2EBD72' : colors.muted }]} /></View>
          <View style={styles.headCopy}><Text style={[styles.name, { color: colors.ink }]}>{person?.name || handle}</Text><Text style={[styles.handleText, { color: colors.mutedForeground }]}>{person?.online ? 'Online' : `@${handle}`}</Text></View>
        </View>
        <FlatList data={messagesForChat} keyExtractor={(m) => m.id} contentContainerStyle={{ paddingVertical: 18, flexGrow: 1 }} ListEmptyComponent={<View style={styles.empty}><Feather name="message-circle" size={32} color={colors.mutedForeground} /><Text style={[styles.emptyTitle, { color: colors.ink }]}>Start the conversation</Text><Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Send a friendly message to @{handle}.</Text></View>} renderItem={({ item }) => <Pressable onLongPress={() => Alert.alert('Delete message?', 'This removes the message from this device.', [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: () => deleteMessage(item.id) }])} style={[styles.bubble, { alignSelf: item.from === user.handle ? 'flex-end' : 'flex-start', backgroundColor: item.from === user.handle ? colors.coral : colors.card, borderColor: colors.border }]}><Text style={{ color: item.from === user.handle ? colors.background : colors.ink, fontFamily: 'Inter_400Regular', fontSize: 14 }}>{item.text}</Text><Text style={[styles.time, { color: item.from === user.handle ? colors.background : colors.mutedForeground }]}>{item.time}{item.from === user.handle ? (item.read ? '  ✓✓' : '  ✓') : ''}</Text></Pressable>} />
        <View style={[styles.composer, { borderColor: colors.border }]}><TextInput value={text} onChangeText={setText} onSubmitEditing={submit} placeholder="Write a message..." placeholderTextColor={colors.placeholder} style={[styles.input, { color: colors.ink, backgroundColor: colors.card, borderColor: colors.border }]} /><Pressable onPress={submit} style={[styles.send, { backgroundColor: text.trim() ? colors.coral : colors.muted }]}><Feather name="send" size={17} color={text.trim() ? colors.background : colors.mutedForeground} /></Pressable></View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen:{flex:1,paddingHorizontal:16}, wrap:{flex:1}, inboxHeader:{alignItems:'center',flexDirection:'row',justifyContent:'space-between',paddingBottom:18,paddingTop:20}, title:{fontFamily:'Inter_700Bold',fontSize:29,letterSpacing:-.7}, subtitle:{fontFamily:'Inter_400Regular',fontSize:12,marginTop:4}, headerButton:{alignItems:'center',borderRadius:12,height:40,justifyContent:'center',width:40}, tabs:{borderRadius:14,borderWidth:1,flexDirection:'row',padding:3,marginBottom:8}, tab:{alignItems:'center',borderRadius:10,flex:1,paddingVertical:9}, tabText:{fontFamily:'Inter_600SemiBold',fontSize:12}, chatRow:{alignItems:'center',borderBottomWidth:StyleSheet.hairlineWidth,flexDirection:'row',paddingVertical:14}, chatCopy:{flex:1,marginLeft:12}, nameLine:{alignItems:'center',flexDirection:'row',gap:7}, name:{fontFamily:'Inter_700Bold',fontSize:14}, preview:{fontFamily:'Inter_400Regular',fontSize:12,marginTop:5}, chatTime:{fontFamily:'Inter_400Regular',fontSize:10,alignSelf:'flex-start',marginTop:5}, badge:{alignItems:'center',borderRadius:9,minWidth:18,paddingHorizontal:5,paddingVertical:2}, badgeText:{fontFamily:'Inter_700Bold',fontSize:9}, onlineDot:{borderWidth:2,borderColor:'#fff',borderRadius:7,bottom:0,height:12,position:'absolute',right:0,width:12}, headerDot:{bottom:0}, header:{alignItems:'center',flexDirection:'row',gap:10,paddingTop:12}, headCopy:{flex:1}, handleText:{fontFamily:'Inter_400Regular',fontSize:11,marginTop:2}, bubble:{borderRadius:16,borderWidth:1,marginBottom:9,maxWidth:'78%',paddingHorizontal:13,paddingVertical:10}, time:{fontFamily:'Inter_400Regular',fontSize:9,marginTop:5}, composer:{alignItems:'center',borderTopWidth:1,flexDirection:'row',gap:8,paddingVertical:10}, input:{borderRadius:14,borderWidth:1,flex:1,fontFamily:'Inter_400Regular',height:46,paddingHorizontal:14}, send:{alignItems:'center',borderRadius:14,height:46,justifyContent:'center',width:46}, empty:{alignItems:'center',flex:1,justifyContent:'center',paddingHorizontal:25}, emptyTitle:{fontFamily:'Inter_700Bold',fontSize:16,marginTop:12}, emptyText:{fontFamily:'Inter_400Regular',fontSize:12,marginTop:5,textAlign:'center'},
});
