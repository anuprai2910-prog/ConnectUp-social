import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useSignup } from '@workspace/api-client-react';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';
import { IconButton, Wordmark } from '@/components/ConnectUpUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';

type SignupErrors = {
  username?: string;
  email?: string;
  password?: string;
  confirmPassword?: string;
};

export default function SignupScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { signIn } = useApp();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState<SignupErrors>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const signupMutation = useSignup({
    mutation: {
      onSuccess: async (account) => {
        const result = await signIn(account.email, password);
        if (!result.ok) { setServerError(result.error ?? 'Account created, but automatic sign in failed. Please sign in manually.'); return; }
        router.replace('/(tabs)/profile');
      },
      onError: (error) => {
        setServerError(error.data?.error ?? 'We could not create your account. Please try again.');
      },
    },
  });

  const handleSignup = () => {
    const nextErrors: SignupErrors = {};
    const normalizedUsername = username.trim();
    const normalizedEmail = email.trim().toLowerCase();
    const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail);
    const isUsernameValid = /^[a-zA-Z0-9_]{3,20}$/.test(normalizedUsername);

    if (!isUsernameValid) {
      nextErrors.username = 'Use 3–20 letters, numbers, or underscores.';
    }
    if (!isEmailValid) {
      nextErrors.email = 'Enter a valid email address.';
    }
    if (password.length < 6) {
      nextErrors.password = 'Use at least 6 characters.';
    }
    if (password !== confirmPassword) {
      nextErrors.confirmPassword = 'Passwords do not match.';
    }
    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }
    setErrors({});
    setServerError(null);
    signupMutation.mutate({
      data: {
        username: normalizedUsername,
        email: normalizedEmail,
        password,
      },
    });
  };

  return (
    <KeyboardAwareScrollViewCompat
      bottomOffset={72}
      contentContainerStyle={[styles.scroll, { paddingTop: insets.top + 18, paddingBottom: insets.bottom + 24 }]}
      style={[styles.screen, { backgroundColor: colors.background }]}
    >
        <View style={styles.header}>
          <IconButton name="arrow-left" onPress={() => router.replace('/')} testID="signup-back" />
          <Wordmark compact />
          <View style={styles.headerSpacer} />
        </View>
        <View style={styles.hero}>
          <Text style={[styles.eyebrow, { color: colors.coral }]}>START SOMETHING GOOD</Text>
          <Text style={[styles.title, { color: colors.ink }]}>Make room{"\n"}for more.</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Create your HITSUN profile and find your people in one place.</Text>
        </View>
        <View style={styles.form}>
          <View>
            <Text style={[styles.label, { color: colors.ink }]}>Username</Text>
            <TextInput
              autoCapitalize="none"
              autoCorrect={false}
              onChangeText={(value) => {
                setUsername(value.replace(/\s/g, ''));
                if (errors.username) setErrors((current) => ({ ...current, username: undefined }));
                if (serverError) setServerError(null);
              }}
              placeholder="yourname"
              placeholderTextColor={colors.placeholder}
              style={[styles.input, { backgroundColor: colors.card, borderColor: errors.username ? colors.coral : colors.border, color: colors.ink }]}
              testID="signup-username"
            />
            {errors.username ? <Text style={[styles.fieldError, { color: colors.coral }]}>{errors.username}</Text> : <Text style={[styles.helper, { color: colors.mutedForeground }]}>This is how people will find you.</Text>}
          </View>
          <View>
            <Text style={[styles.label, { color: colors.ink }]}>Email address</Text>
            <TextInput
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="email-address"
              onChangeText={(value) => {
                setEmail(value);
                if (errors.email) setErrors((current) => ({ ...current, email: undefined }));
                if (serverError) setServerError(null);
              }}
              placeholder="you@example.com"
              placeholderTextColor={colors.placeholder}
              style={[styles.input, { backgroundColor: colors.card, borderColor: errors.email ? colors.coral : colors.border, color: colors.ink }]}
              testID="signup-email"
            />
            {errors.email ? <Text style={[styles.fieldError, { color: colors.coral }]}>{errors.email}</Text> : null}
          </View>
          <View>
            <Text style={[styles.label, { color: colors.ink }]}>Create a password</Text>
            <TextInput
              autoCapitalize="none"
              autoCorrect={false}
              onChangeText={(value) => {
                setPassword(value);
                if (errors.password) setErrors((current) => ({ ...current, password: undefined }));
                if (errors.confirmPassword) setErrors((current) => ({ ...current, confirmPassword: undefined }));
                if (serverError) setServerError(null);
              }}
              placeholder="At least 6 characters"
              placeholderTextColor={colors.placeholder}
              secureTextEntry
              style={[styles.input, { backgroundColor: colors.card, borderColor: errors.password ? colors.coral : colors.border, color: colors.ink }]}
              testID="signup-password"
            />
            {errors.password ? <Text style={[styles.fieldError, { color: colors.coral }]}>{errors.password}</Text> : null}
          </View>
          <View>
            <Text style={[styles.label, { color: colors.ink }]}>Confirm password</Text>
            <TextInput
              autoCapitalize="none"
              autoCorrect={false}
              onChangeText={(value) => {
                setConfirmPassword(value);
                if (errors.confirmPassword) setErrors((current) => ({ ...current, confirmPassword: undefined }));
                if (serverError) setServerError(null);
              }}
              placeholder="Repeat your password"
              placeholderTextColor={colors.placeholder}
              secureTextEntry
              style={[styles.input, { backgroundColor: colors.card, borderColor: errors.confirmPassword ? colors.coral : colors.border, color: colors.ink }]}
              testID="signup-confirm-password"
            />
            {errors.confirmPassword ? <Text style={[styles.fieldError, { color: colors.coral }]}>{errors.confirmPassword}</Text> : null}
          </View>
          <Text style={[styles.privacyNote, { color: colors.mutedForeground }]}>
            Your password is encrypted before it is stored and is never returned to the app.
          </Text>
          {serverError ? <Text style={[styles.serverError, { color: colors.coral }]} testID="signup-server-error">{serverError}</Text> : null}
          <Pressable disabled={signupMutation.isPending} onPress={handleSignup} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.coral }, signupMutation.isPending && styles.disabled, pressed && styles.pressed]} testID="signup-submit">
            <Text style={[styles.primaryButtonText, { color: colors.background }]}>{signupMutation.isPending ? 'Creating your account…' : 'Continue to profile'}</Text>
            <Feather name="arrow-up-right" size={18} color={colors.background} />
          </Pressable>
        </View>
        <View style={styles.loginRow}>
          <Text style={[styles.loginPrompt, { color: colors.mutedForeground }]}>Already have an account?</Text>
          <Pressable onPress={() => router.replace('/')}>
            <Text style={[styles.loginLink, { color: colors.coral }]}>Sign in</Text>
          </Pressable>
        </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  scroll: { flexGrow: 1, paddingHorizontal: 24 },
  header: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' },
  headerSpacer: { width: 32 },
  hero: { marginTop: 54 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.4 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 40, letterSpacing: -1.8, lineHeight: 43, marginTop: 12 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 15, lineHeight: 23, marginTop: 18, maxWidth: 320 },
  form: { gap: 16, marginTop: 38 },
  label: { fontFamily: 'Inter_600SemiBold', fontSize: 12, marginBottom: 8 },
  input: { borderRadius: 14, borderWidth: 1, fontFamily: 'Inter_400Regular', fontSize: 15, height: 54, paddingHorizontal: 16 },
  helper: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 7 },
  fieldError: { fontFamily: 'Inter_500Medium', fontSize: 11, marginTop: 7 },
  privacyNote: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: -2 },
  serverError: { fontFamily: 'Inter_500Medium', fontSize: 12, lineHeight: 17, marginTop: -4 },
  primaryButton: { alignItems: 'center', borderRadius: 15, flexDirection: 'row', height: 56, justifyContent: 'center', marginTop: 2, gap: 9 },
  primaryButtonText: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  loginRow: { alignItems: 'center', flexDirection: 'row', gap: 5, justifyContent: 'center', marginTop: 'auto', paddingTop: 48 },
  loginPrompt: { fontFamily: 'Inter_400Regular', fontSize: 13 },
  loginLink: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  pressed: { opacity: 0.82, transform: [{ scale: 0.985 }] },
  disabled: { opacity: 0.6 },
});