/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // HITSUN's warm editorial palette.
    text: '#17212B',
    tint: '#E76F51',

    // Core surfaces
    background: '#FBF9F6',
    foreground: '#17212B',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#17212B',

    // Primary action color (buttons, links, active states)
    primary: '#E76F51',
    primaryForeground: '#FFFFFF',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#F4F0EA',
    secondaryForeground: '#17212B',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#EFEAE3',
    mutedForeground: '#7E858A',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#E8F1EC',
    accentForeground: '#17212B',

    // Destructive actions (delete, error states)
    destructive: '#C54B46',
    destructiveForeground: '#FFFFFF',

    // Borders and input outlines
    border: '#E7E1D9',
    input: '#E7E1D9',

    // HITSUN-specific semantic accents
    ink: '#17212B',
    coral: '#E76F51',
    sun: '#F4B84A',
    sand: '#F6E5D7',
    mint: '#E1EFE8',
    mintDark: '#56836E',
    borderStrong: '#CFC7BC',
    placeholder: '#A8AAA8',
    softCard: '#F4F0EA',
    avatarPalette: ['#F8C7B4', '#B8D8D0', '#D4C6F0', '#F2D990', '#C7D8F2'],
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 14,
};

export default colors;
