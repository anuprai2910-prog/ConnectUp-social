import app from "./app";
import { logger } from "./lib/logger";
import { pool } from "@workspace/db";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

async function start() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS messages (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      from_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      to_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      text text NOT NULL,
      created_at timestamptz NOT NULL DEFAULT now(),
      read_at timestamptz
    )
  `);
  await pool.query(`CREATE INDEX IF NOT EXISTS messages_from_to_idx ON messages(from_user_id, to_user_id, created_at)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS messages_to_from_idx ON messages(to_user_id, from_user_id, created_at)`);

  app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

    logger.info({ port }, "Server listening");
  });
}

start().catch((err) => {
  logger.error({ err }, "Unable to start server");
  process.exit(1);
});
