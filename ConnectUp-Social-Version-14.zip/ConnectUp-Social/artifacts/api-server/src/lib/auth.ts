import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";

const sessions = new Map<string, string>();

export function createSession(userId: string): string {
  const token = randomBytes(32).toString("hex");
  sessions.set(token, userId);
  return token;
}

export async function getUserFromToken(token: string | undefined) {
  if (!token) return null;
  const userId = sessions.get(token);
  if (!userId) return null;
  const [user] = await db.select({ id: usersTable.id, username: usersTable.username, email: usersTable.email })
    .from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  return user ?? null;
}

export function destroySession(token: string | undefined) {
  if (token) sessions.delete(token);
}
