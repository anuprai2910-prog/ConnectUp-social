import { Router, type IRouter, type Request } from "express";
import { and, eq, or } from "drizzle-orm";
import { db, messagesTable, usersTable } from "@workspace/db";
import { getUserFromToken } from "../lib/auth";

const router: IRouter = Router();

async function currentUser(req: Request) {
  const header = req.header("authorization") ?? "";
  return getUserFromToken(header.startsWith("Bearer ") ? header.slice(7) : undefined);
}

router.get("/messages", async (req, res): Promise<void> => {
  const user = await currentUser(req);
  if (!user) { res.status(401).json({ error: "Unauthorized" }); return; }
  const rows = await db.select({
    id: messagesTable.id,
    fromUserId: messagesTable.fromUserId,
    toUserId: messagesTable.toUserId,
    text: messagesTable.text,
    createdAt: messagesTable.createdAt,
    readAt: messagesTable.readAt,
  }).from(messagesTable)
    .where(or(eq(messagesTable.fromUserId, user.id), eq(messagesTable.toUserId, user.id)))
    .orderBy(messagesTable.createdAt).limit(500);

  const userIds = [...new Set(rows.flatMap((row) => [row.fromUserId, row.toUserId]))];
  const people = userIds.length ? await db.select({ id: usersTable.id, username: usersTable.username }).from(usersTable) : [];
  const names = new Map(people.map((person) => [person.id, person.username]));
  res.json({ messages: rows.map((row) => ({
    id: row.id,
    from: names.get(row.fromUserId) ?? "unknown",
    to: names.get(row.toUserId) ?? "unknown",
    text: row.text,
    createdAt: row.createdAt.toISOString(),
    read: row.readAt !== null,
  })) });
});

router.post("/messages", async (req, res): Promise<void> => {
  const user = await currentUser(req);
  if (!user) { res.status(401).json({ error: "Unauthorized" }); return; }
  const to = typeof req.body?.to === "string" ? req.body.to.trim().toLowerCase() : "";
  const text = typeof req.body?.text === "string" ? req.body.text.trim() : "";
  if (!to || !text || text.length > 4000) { res.status(400).json({ error: "Recipient and message are required." }); return; }
  const [recipient] = await db.select({ id: usersTable.id, username: usersTable.username }).from(usersTable).where(eq(usersTable.username, to)).limit(1);
  if (!recipient) { res.status(404).json({ error: "User not found." }); return; }
  const [message] = await db.insert(messagesTable).values({ fromUserId: user.id, toUserId: recipient.id, text }).returning();
  res.status(201).json({ id: message.id, from: user.username, to: recipient.username, text: message.text, createdAt: message.createdAt.toISOString(), read: false });
});

router.post("/messages/read", async (req, res): Promise<void> => {
  const user = await currentUser(req);
  if (!user) { res.status(401).json({ error: "Unauthorized" }); return; }
  const from = typeof req.body?.from === "string" ? req.body.from.trim().toLowerCase() : "";
  if (!from) { res.status(400).json({ error: "Sender is required." }); return; }
  const [sender] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.username, from)).limit(1);
  if (!sender) { res.status(404).json({ error: "User not found." }); return; }
  await db.update(messagesTable).set({ readAt: new Date() }).where(and(eq(messagesTable.fromUserId, sender.id), eq(messagesTable.toUserId, user.id)));
  res.status(204).end();
});

router.delete("/messages/:id", async (req, res): Promise<void> => {
  const user = await currentUser(req);
  if (!user) { res.status(401).json({ error: "Unauthorized" }); return; }
  await db.delete(messagesTable).where(and(eq(messagesTable.id, req.params.id), eq(messagesTable.fromUserId, user.id)));
  res.status(204).end();
});

export default router;
