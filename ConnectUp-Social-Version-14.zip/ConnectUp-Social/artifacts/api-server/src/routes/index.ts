import { Router, type IRouter } from "express";
import authRouter from "./auth";
import messagesRouter from "./messages";
import storiesRouter from "./stories";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(messagesRouter);
router.use(storiesRouter);

export default router;
