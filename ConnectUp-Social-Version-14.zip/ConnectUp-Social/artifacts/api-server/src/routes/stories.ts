import { Router, type IRouter, type Request } from "express";
import { and, eq, gt, inArray } from "drizzle-orm";
import { db, storiesTable, storyViewsTable, storyReactionsTable, usersTable } from "@workspace/db";
import { getUserFromToken } from "../lib/auth";

const router: IRouter = Router();
async function currentUser(req: Request) {
  const h = req.header("authorization") ?? "";
  return getUserFromToken(h.startsWith("Bearer ") ? h.slice(7) : undefined);
}

router.get("/stories", async (req, res): Promise<void> => {
  const user = await currentUser(req);
  if (!user) { res.status(401).json({ error: "Unauthorized" }); return; }
  const now = new Date();
  const rows = await db.select({ story: storiesTable, username: usersTable.username })
    .from(storiesTable).innerJoin(usersTable, eq(storiesTable.userId, usersTable.id))
    .where(gt(storiesTable.expiresAt, now)).orderBy(storiesTable.createdAt);
  const ids = rows.map(r => r.story.id);
  const views = ids.length ? await db.select({ storyId: storyViewsTable.storyId }).from(storyViewsTable).where(and(inArray(storyViewsTable.storyId, ids), eq(storyViewsTable.userId, user.id))) : [];
  const reactions = ids.length ? await db.select({ storyId: storyReactionsTable.storyId, reaction: storyReactionsTable.reaction }).from(storyReactionsTable).where(and(inArray(storyReactionsTable.storyId, ids), eq(storyReactionsTable.userId, user.id))) : [];
  const viewed = new Set(views.map(v => v.storyId));
  const reacted = new Map(reactions.map(r => [r.storyId, r.reaction]));
  res.json({ stories: rows.map(r => ({ id:r.story.id, username:r.username, text:r.story.text, mediaUrl:r.story.mediaUrl, mediaType:r.story.mediaType, createdAt:r.story.createdAt.toISOString(), expiresAt:r.story.expiresAt.toISOString(), viewed:viewed.has(r.story.id), reaction:reacted.get(r.story.id) ?? null })) });
});

router.post("/stories", async (req, res): Promise<void> => {
  const user = await currentUser(req);
  if (!user) { res.status(401).json({ error: "Unauthorized" }); return; }
  const text = typeof req.body?.text === "string" ? req.body.text.trim() : "";
  const mediaUrl = typeof req.body?.mediaUrl === "string" ? req.body.mediaUrl : null;
  const mediaType = typeof req.body?.mediaType === "string" ? req.body.mediaType : null;
  if (!text && !mediaUrl) { res.status(400).json({ error: "Add text or media to your story." }); return; }
  if (text.length > 500) { res.status(400).json({ error: "Story text is too long." }); return; }
  if (mediaUrl && mediaUrl.length > 8_000_000) { res.status(413).json({ error: "Media is too large." }); return; }
  const createdAt = new Date(); const expiresAt = new Date(createdAt.getTime() + 24 * 60 * 60 * 1000);
  const [story] = await db.insert(storiesTable).values({ userId:user.id, text, mediaUrl, mediaType, createdAt, expiresAt }).returning();
  res.status(201).json({ id:story.id, username:user.username, text:story.text, mediaUrl:story.mediaUrl, mediaType:story.mediaType, createdAt:story.createdAt.toISOString(), expiresAt:story.expiresAt.toISOString(), viewed:true, reaction:null });
});

router.post("/stories/:id/view", async (req, res): Promise<void> => {
  const user = await currentUser(req); if (!user) { res.status(401).json({ error:"Unauthorized" }); return; }
  const [story] = await db.select({ id:storiesTable.id }).from(storiesTable).where(eq(storiesTable.id, req.params.id)).limit(1);
  if (!story) { res.status(404).json({ error:"Story not found." }); return; }
  await db.insert(storyViewsTable).values({ storyId:story.id, userId:user.id }).onConflictDoNothing();
  res.status(204).end();
});

router.post("/stories/:id/react", async (req, res): Promise<void> => {
  const user = await currentUser(req); if (!user) { res.status(401).json({ error:"Unauthorized" }); return; }
  const reaction = typeof req.body?.reaction === "string" ? req.body.reaction.slice(0, 8) : "❤️";
  await db.insert(storyReactionsTable).values({ storyId:req.params.id, userId:user.id, reaction }).onConflictDoUpdate({ target:[storyReactionsTable.storyId, storyReactionsTable.userId], set:{ reaction } });
  res.json({ reaction });
});

router.delete("/stories/:id/react", async (req, res): Promise<void> => {
  const user = await currentUser(req); if (!user) { res.status(401).json({ error:"Unauthorized" }); return; }
  await db.delete(storyReactionsTable).where(and(eq(storyReactionsTable.storyId, req.params.id), eq(storyReactionsTable.userId, user.id)));
  res.status(204).end();
});

router.get("/stories/:id/viewers", async (req, res): Promise<void> => {
  const user = await currentUser(req); if (!user) { res.status(401).json({ error:"Unauthorized" }); return; }
  const [story] = await db.select({ userId:storiesTable.userId }).from(storiesTable).where(eq(storiesTable.id, req.params.id)).limit(1);
  if (!story || story.userId !== user.id) { res.status(403).json({ error:"Only the story owner can see viewers." }); return; }
  const rows = await db.select({ username:usersTable.username, viewedAt:storyViewsTable.createdAt }).from(storyViewsTable).innerJoin(usersTable, eq(storyViewsTable.userId, usersTable.id)).where(eq(storyViewsTable.storyId, req.params.id));
  res.json({ viewers:rows.map(r => ({ username:r.username, viewedAt:r.viewedAt.toISOString() })) });
});

export default router;
