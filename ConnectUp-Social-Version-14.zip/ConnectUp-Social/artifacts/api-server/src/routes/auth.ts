import { Router, type IRouter } from "express";
import { eq, or } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import { SignupBody, SignupResponse } from "@workspace/api-zod";
import { hashPassword, verifyPassword } from "../lib/password";
import { createSession, destroySession, getUserFromToken } from "../lib/auth";

const router: IRouter = Router();

router.post("/auth/signup", async (req, res): Promise<void> => {
  const parsed = SignupBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const username = parsed.data.username.trim();
  const email = parsed.data.email.trim().toLowerCase();
  const [existingUser] = await db.select({ id: usersTable.id }).from(usersTable)
    .where(or(eq(usersTable.username, username), eq(usersTable.email, email))).limit(1);
  if (existingUser) { res.status(409).json({ error: "Username or email is already in use." }); return; }
  const passwordHash = await hashPassword(parsed.data.password);
  try {
    const [user] = await db.insert(usersTable).values({ username, email, passwordHash }).returning({ id: usersTable.id, username: usersTable.username, email: usersTable.email, createdAt: usersTable.createdAt });
    res.status(201).json(SignupResponse.parse(user));
  } catch (error: unknown) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") { res.status(409).json({ error: "Username or email is already in use." }); return; }
    throw error;
  }
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  if (!email || !password) { res.status(400).json({ error: "Email and password are required." }); return; }
  const [user] = await db.select({ id: usersTable.id, username: usersTable.username, email: usersTable.email, passwordHash: usersTable.passwordHash })
    .from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (!user || !(await verifyPassword(password, user.passwordHash))) { res.status(401).json({ error: "Invalid email or password." }); return; }
  const token = createSession(user.id);
  res.json({ id: user.id, username: user.username, email: user.email, token });
});

router.post("/auth/logout", async (req, res) => {
  const header = req.header("authorization") ?? "";
  destroySession(header.startsWith("Bearer ") ? header.slice(7) : undefined);
  res.status(204).end();
});

router.get("/auth/me", async (req, res): Promise<void> => {
  const header = req.header("authorization") ?? "";
  const user = await getUserFromToken(header.startsWith("Bearer ") ? header.slice(7) : undefined);
  if (!user) { res.status(401).json({ error: "Unauthorized" }); return; }
  res.json(user);
});

export default router;
