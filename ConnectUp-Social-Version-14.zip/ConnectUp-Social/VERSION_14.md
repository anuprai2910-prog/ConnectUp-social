# HITSUN / ConnectUp — Version 14

## Stories / Status
- Create photo or text stories.
- Stories expire after 24 hours.
- Stories are stored server-side in PostgreSQL.
- Story viewers are recorded per user.
- Story owner can view the viewer list.
- Users can react/unreact to stories.
- Home feed shows active stories and opens the story viewer.
- Story viewer supports previous/next navigation.
- Image stories use a base64 data URL so the current prototype works without a separate object-storage service.

## Database
New tables:
- `stories`
- `story_views`
- `story_reactions`

After installing dependencies and provisioning the database, run:
`pnpm --filter @workspace/db push`

## API
- GET /api/stories
- POST /api/stories
- POST /api/stories/:id/view
- POST /api/stories/:id/react
- DELETE /api/stories/:id/react
- GET /api/stories/:id/viewers
